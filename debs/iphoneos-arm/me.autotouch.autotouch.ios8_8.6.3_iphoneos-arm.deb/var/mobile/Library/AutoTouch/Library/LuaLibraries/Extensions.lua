print = log

-- Consumer Page in IOKit/hid/IOHIDUsageTables.h
KEY_TYPE = {
    HOME_BUTTON = 0x40,
    VOLUME_DOWN_BUTTON = 0xEA,
    VOLUME_UP_BUTTON = 0xE9,
    POWER_BUTTON = 0x30
}

ORIENTATION_TYPE = {
    UNKNOWN = 0,
    PORTRAIT = 1, -- Device oriented vertically, home button on the bottom
    PORTRAIT_UPSIDE_DOWN = 2, -- Device oriented vertically, home button on the top
    LANDSCAPE_LEFT = 3, -- Device oriented horizontally, home button on the right
    LANDSCAPE_RIGHT = 4 -- Device oriented horizontally, home button on the left
}

CONTROLLER_TYPE = {
    LABEL = 1,
    INPUT = 2,
    PICKER = 3,
    SWITCH = 4,
    BUTTON = 5,
    REMEMBER = 6,
    TEXTVIEW = 7
}

OCR_METHOD = {
    IOS_VISION = 1,
    AI_CLOUD = 2,
    -- Reserved for compatibility. Current builds return an explicit error
    -- instead of silently sending this "local" request to the cloud.
    TESSERACT_LOCAL = 3
}

----------------------------------------

function lockScreen()
    keyDown(KEY_TYPE.POWER_BUTTON)
    keyUp(KEY_TYPE.POWER_BUTTON)
end

-- unlockScreen([passcode]) is now a native function (LuaProxy.m -> unlockScreenToHome_631947):
-- it does wake + authenticate (optional passcode) + dismiss the lock screen to home,
-- all natively. The previous Lua wrapper (nativeUnlockScreen + coordinate swipe) was
-- removed so the ergonomic name maps directly to the native implementation.

----------------------------------------

function intToRgb(intColor)
    local r = math.floor(intColor / (256 * 256))
    local g = math.floor((intColor - r * 256 * 256) / 256)
    local b = math.floor((intColor - r * 256 * 256 - g * 256))
    return r, g, b
end

function rgbToInt(r, g, b)
    return r * 256 * 256 + g * 256 + b
end

function getColor(x, y)
    local colors = getColors({{x, y}})
    if colors ~= nil and #colors > 0 then
        return colors[1]
    end
    return -1
end

-- color: the color to find
-- count: 0 means all, 1 means first, 2 means first and second
-- region: region
-- debug: debug mode
function findColor(color, count, region, debug, rightToLeft, bottomToTop)
    return findColors({{color, 0, 0}}, count, region, debug, rightToLeft, bottomToTop)
end

function dialog(controls, orientations)
    return dialog2(controls, orientations)
end

function exit()
    return stop()
end

function rootPathOfDocuments()
    return rootDir()
end

function tap(x, y)
    touchDown(0, x, y)
    usleep(16000)
    touchUp(0, x, y)
end

-- color: the color to find
-- count: 0 means all, 1 means first, 2 means first and second
-- region: region
function findColorTap(color, count, region)
    local result = findColor(color, count, region)
    if result ~= nil then
        for _, v in ipairs(result) do
            tap(v[1], v[2])
            usleep(16000)
        end
    end
    return result
end

-- will block current process
function findColorsTap(colors, count, region)
    local locations = findColors(colors, count, region)
    if locations ~= nil then
        for _, v in ipairs(locations) do
            tap(v[1], v[2])
            usleep(16000)
        end
    end
    return locations
end

function findImageTap(imagePath, count, threshold, region, debug, method)
    local locations = findImage(imagePath, count, threshold, region, debug, method)
    if locations ~= nil then
        for _, v in ipairs(locations) do
            tap(v[1], v[2])
            usleep(16000)
        end
    end
    return locations
end

-- interval: milliseconds
function keepFindingColor(color, count, region, func, interval, exit)
    local f = function()
        local locations = findColor(color, count, region)
        if func ~= nil then
            func(locations)
        end
        return locations ~= nil and #locations > 0
    end

    keep(f, interval, exit)
end

function keep(func, interval, exit)
    local intervalMicroseconds = 1000000
    if type(interval) == "number" and interval > 0 then
        intervalMicroseconds = math.floor(interval * 1000)
    end

    local firstLoop = true
    while true do
        if firstLoop then
            firstLoop = false
        else
            usleep(intervalMicroseconds)
        end

        local shouldExit = func()
        if exit and shouldExit then
            return
        end
    end
end

-- will block current process until the callback returns a truthy value when exit is true
-- func: the action you want to run when the colors are found, it should be like: local f = function (locations) ... end
function keepFindingColors(colors, count, region, func, interval, exit)
    local f = function()
        local locations = findColors(colors, count, region)
        if func ~= nil then
            func(locations)
        end
        return locations ~= nil and #locations > 0
    end

    keep(f, interval, exit)
end

function keepFindingImage(imagePath, count, threshold, region, debug, method, func, interval, exit)
    local f = function()
        local locations = findImage(imagePath, count, threshold, region, debug, method)
        if func ~= nil then
            func(locations)
        end
        return locations ~= nil and #locations > 0
    end

    keep(f, interval, exit)
end

function keepFindingColorTap(color, count, region, interval, exit)
    local f = function()
        local locations = findColorTap(color, count, region)
        return locations ~= nil and #locations > 0
    end

    keep(f, interval, exit)
end

function keepFindingColorsTap(colors, count, region, interval, exit)
    local f = function()
        local locations = findColorsTap(colors, count, region)
        return locations ~= nil and #locations > 0
    end

    keep(f, interval, exit)
end

function keepFindingImageTap(imagePath, count, threshold, region, debug, method, interval, exit)
    local f = function()
        local locations = findImageTap(imagePath, count, threshold, region, debug, method)
        return locations ~= nil and #locations > 0
    end

    keep(f, interval, exit)
end

function keyPress(keyType)
    keyDown(keyType)
    usleep(10000)
    keyUp(keyType)
end

function appIsActive(appIdentifier)
    local frontId = frontMostAppId()
    if appIdentifier == "com.apple.SpringBoard" then
        return frontId == nil or frontId == ""
    end
    return frontId == appIdentifier or "ACTIVATED" == appState(appIdentifier)
end

function appRun(appIdentifier)
    if appIdentifier == "com.apple.SpringBoard" then
        keyPress(KEY_TYPE.HOME_BUTTON)
    else
        appDoRun(appIdentifier)
    end
end

function appActivate(appIdentifier, timeoutSeconds)
    timeoutSeconds = timeoutSeconds or 30
    if type(timeoutSeconds) ~= "number" or
       timeoutSeconds ~= timeoutSeconds or
       timeoutSeconds <= 0 or
       timeoutSeconds > 300 then
        error("appActivate timeout must be a finite number in the range (0, 300]")
    end

    local attemptsRemaining = math.max(1, math.ceil(timeoutSeconds * 2))
    local firstLoop = true
    while not appIsActive(appIdentifier) do
        if attemptsRemaining <= 0 then
            return false
        end
        attemptsRemaining = attemptsRemaining - 1

        if not firstLoop then
            usleep(500000)
        else
            firstLoop = false
        end
        appRun(appIdentifier)
    end
    return true
end
----------------------------------------

function table.tostring(tbl)
    return table.toString(tbl, false)
end

function table.toString(t, pretty)
    local indent = pretty and "  " or ""
    local visiting = {}
    local function serialize(val, depth)
        if type(val) == "table" then
            if depth > 64 then
                error("Maximum table serialization depth exceeded")
            end
            if visiting[val] then
                error("Cannot serialize a table with cyclic references")
            end
            visiting[val] = true
            local str = "{\n"
            for k, v in pairs(val) do
                str = str .. string.rep(indent, depth + 1) .. serialize(k, depth + 1) .. ": " .. serialize(v, depth + 1) .. ",\n"
            end
            visiting[val] = nil
            return str .. string.rep(indent, depth) .. "}"
        elseif type(val) == "string" then
            return '"' .. val:gsub('"', '\\"'):gsub("\n", "\\n"):gsub("\t", "\\t") .. '"'
        elseif type(val) == "number" or type(val) == "boolean" or val == nil then
            return tostring(val)
        else
            error("Unsupported data type: " .. type(val))
        end
    end
    return serialize(t, 0)
end

---------------------------------------
-- pixel = {color, offsetX, offsetY}
function centerOffsetOfPixels(pixels)
    local points = {}
    for _, v in ipairs(pixels) do
        table.insert(points, {v[2], v[3]})
    end

    return centerOffsetOfPoints(points)
end

-- point = {x, y}
function centerOffsetOfPoints(points)
    if type(points) ~= "table" or #points == 0 then
        error("centerOffsetOfPoints expects a non-empty point array")
    end

    local firstPoint = points[1]

    local leftMost = firstPoint[1]
    local rightMost = firstPoint[1]
    local topMost = firstPoint[2]
    local bottomMost = firstPoint[2]

    for i = 2, #points do
        local v = points[i]

        if (v[1] < leftMost) then
            leftMost = v[1]
        end
        if (v[1] > rightMost) then
            rightMost = v[1]
        end
        if (v[2] < topMost) then
            topMost = v[2]
        end
        if (v[2] > bottomMost) then
            bottomMost = v[2]
        end
    end

    local size = {rightMost - leftMost, bottomMost - topMost}
    local centerOffset = {size[1] / 2 + leftMost, size[2] / 2 + topMost}
    return centerOffset
end

function string.starts_with(str, start)
    return str:sub(1, #start) == start
end

function string.ends_with(str, ending)
    return ending == "" or str:sub(-(#ending)) == ending
end

function currentPath()
    return playingDir
end

function currentDir()
    return playingDir
end

function botPath()
    return botPath_
end
