-----------------------------------------------------------------------------
-- AutoTouch secure HTTPS policy for LuaSocket + LuaSec.
--
-- This API always verifies the peer chain and matches the requested host
-- against the leaf certificate's subjectAltName. The conventional ssl.https
-- module is a compatibility facade for this same policy; neither entry point
-- offers a verify="none" escape hatch.
-----------------------------------------------------------------------------

local socket = require("socket")
local ssl = require("ssl")
local ltn12 = require("ltn12")
local http = require("socket.http")
local url = require("socket.url")

local protected_call = pcall
local extended_protected_call = xpcall
local raise = error
local stringify = tostring

local M = {
    _VERSION = "AutoTouch Secure HTTPS 1.0",
    PORT = 443,
    TIMEOUT = 60,
}

local TLS_OPTIONS = {
    "all",
    "no_sslv2",
    "no_sslv3",
    "no_tlsv1",
    "no_tlsv1_1",
}

local DEFAULT_CA_FILES = {
    "/etc/ssl/certs/cacert.pem",
    "/etc/ssl/cert.pem",
    "/usr/local/etc/openssl/cert.pem",
    "/var/jb/etc/ssl/certs/cacert.pem",
    "/var/jb/etc/ssl/cert.pem",
}

local function readable_file(path)
    local stream = io.open(path, "rb")
    if not stream then
        return false
    end
    stream:close()
    return true
end

local function default_ca_file()
    for _, candidate in ipairs(DEFAULT_CA_FILES) do
        if readable_file(candidate) then
            return candidate
        end
    end
    return nil
end

local function ipv4_bytes(value)
    if type(value) ~= "string" then
        return nil
    end
    local octets = {string.match(value, "^(%d+)%.(%d+)%.(%d+)%.(%d+)$")}
    if #octets ~= 4 then
        return nil
    end
    local bytes = {}
    for index, octet in ipairs(octets) do
        -- Reject leading zeroes rather than assigning an ambiguous octal or
        -- non-canonical meaning to an IPv4 certificate identity.
        if (#octet > 1 and string.sub(octet, 1, 1) == "0") or #octet > 3 then
            return nil
        end
        local number = tonumber(octet)
        if not number or number > 255 then
            return nil
        end
        bytes[index] = string.char(number)
    end
    return table.concat(bytes)
end

local function ipv6_hextets(section)
    if section == "" then
        return {}
    end
    if string.sub(section, 1, 1) == ":"
        or string.sub(section, -1) == ":"
        or string.find(section, "::", 1, true)
    then
        return nil
    end

    local hextets = {}
    for hextet in string.gmatch(section, "[^:]+") do
        if #hextet > 4 or not string.match(hextet, "^[0-9a-f]+$") then
            return nil
        end
        hextets[#hextets + 1] = tonumber(hextet, 16)
    end
    return hextets
end

local function ipv6_bytes(value)
    if type(value) ~= "string" then
        return nil
    end
    value = string.lower(value)
    if string.sub(value, 1, 1) == "[" and string.sub(value, -1) == "]" then
        value = string.sub(value, 2, -2)
    end
    if value == "" or string.find(value, "%", 1, true) then
        return nil
    end

    -- An embedded IPv4 tail represents the final two IPv6 hextets.
    if string.find(value, ".", 1, true) then
        local prefix, ipv4_tail = string.match(value, "^(.*:)([^:]*)$")
        local tail_bytes = ipv4_bytes(ipv4_tail)
        if not prefix or not tail_bytes then
            return nil
        end
        local first = string.byte(tail_bytes, 1) * 256 + string.byte(tail_bytes, 2)
        local second = string.byte(tail_bytes, 3) * 256 + string.byte(tail_bytes, 4)
        value = prefix .. string.format("%x:%x", first, second)
    end

    local compression_start, compression_end = string.find(value, "::", 1, true)
    local hextets = {}
    if compression_start then
        if string.find(value, "::", compression_end + 1, true) then
            return nil
        end
        local left = ipv6_hextets(string.sub(value, 1, compression_start - 1))
        local right = ipv6_hextets(string.sub(value, compression_end + 1))
        if not left or not right then
            return nil
        end
        local omitted = 8 - #left - #right
        if omitted < 1 then
            return nil
        end
        for _, hextet in ipairs(left) do
            hextets[#hextets + 1] = hextet
        end
        for _ = 1, omitted do
            hextets[#hextets + 1] = 0
        end
        for _, hextet in ipairs(right) do
            hextets[#hextets + 1] = hextet
        end
    else
        hextets = ipv6_hextets(value)
        if not hextets or #hextets ~= 8 then
            return nil
        end
    end

    local bytes = {}
    for _, hextet in ipairs(hextets) do
        bytes[#bytes + 1] = string.char(math.floor(hextet / 256), hextet % 256)
    end
    return table.concat(bytes)
end

local function normalized_ip_bytes(value)
    return ipv4_bytes(value) or ipv6_bytes(value)
end

local function looks_like_ip_literal(value)
    return type(value) == "string"
        and (string.find(value, ":", 1, true) ~= nil
            or string.match(value, "^[%d%.]+$") ~= nil
            or string.sub(value, 1, 1) == "[")
end

local function normalized_dns_name(value)
    if type(value) ~= "string" or value == "" or string.find(value, "\0", 1, true) then
        return nil
    end
    value = string.lower(value)
    if string.sub(value, -1) == "." then
        value = string.sub(value, 1, -2)
    end
    if value == "" or string.find(value, "..", 1, true) then
        return nil
    end
    return value
end

local function dns_name_matches(host, presented_name)
    host = normalized_dns_name(host)
    presented_name = normalized_dns_name(presented_name)
    if not host or not presented_name then
        return false
    end
    if host == presented_name then
        return true
    end

    -- RFC 6125-style conservative wildcard policy: only a complete leftmost
    -- label may be '*', and it matches exactly one non-empty label.
    if string.sub(presented_name, 1, 2) ~= "*."
        or string.find(string.sub(presented_name, 3), "*", 1, true)
    then
        return false
    end
    local suffix = string.sub(presented_name, 3)
    if not string.find(suffix, ".", 1, true) then
        return false
    end
    if #host <= #suffix + 1 or string.sub(host, -#suffix) ~= suffix then
        return false
    end
    if string.sub(host, -#suffix - 1, -#suffix - 1) ~= "." then
        return false
    end
    local leftmost = string.sub(host, 1, #host - #suffix - 1)
    return leftmost ~= "" and not string.find(leftmost, ".", 1, true)
end

local function certificate_matches_host(certificate, host)
    local extensions = certificate:extensions()
    local subject_alt_name = type(extensions) == "table" and extensions["2.5.29.17"] or nil
    if type(subject_alt_name) ~= "table" then
        return false
    end

    local expected_ip = normalized_ip_bytes(host)
    if expected_ip then
        for _, presented_ip in ipairs(subject_alt_name.iPAddress or {}) do
            if normalized_ip_bytes(presented_ip) == expected_ip then
                return true
            end
        end
        return false
    elseif looks_like_ip_literal(host) then
        -- An invalid or ambiguous IP-looking host must never fall back to DNS
        -- SAN matching (for example, IPv4 components with leading zeroes).
        return false
    end

    for _, presented_name in ipairs(subject_alt_name.dNSName or {}) do
        if dns_name_matches(host, presented_name) then
            return true
        end
    end
    return false
end

local function tls_parameters(params)
    params = params or {}
    local configured = {}
    for key, value in pairs(params) do
        configured[key] = value
    end

    if configured.verify ~= nil and configured.verify ~= "peer" then
        error("autotouch.https does not permit disabling peer verification", 3)
    end
    configured.mode = "client"
    configured.protocol = "any"
    configured.verifyext = nil
    configured.verify = "peer"

    local options = {}
    local seen_options = {}
    if type(configured.options) == "table" then
        for _, option in ipairs(configured.options) do
            if type(option) == "string" and not seen_options[option] then
                options[#options + 1] = option
                seen_options[option] = true
            end
        end
    end
    for _, required_option in ipairs(TLS_OPTIONS) do
        if not seen_options[required_option] then
            options[#options + 1] = required_option
            seen_options[required_option] = true
        end
    end
    configured.options = options

    if not configured.cafile and not configured.capath then
        configured.cafile = default_ca_file()
        if not configured.cafile then
            error(
                "autotouch.https could not find a CA bundle; provide cafile or capath",
                3
            )
        end
    end
    return configured
end

local function register_socket_methods(connection)
    local socket_metatable = getmetatable(connection.sock)
    local methods = socket_metatable and socket_metatable.__index
    if type(methods) ~= "table" then
        raise("TLS socket has no method table", 0)
    end
    for name, method in pairs(methods) do
        if name ~= "close" and type(method) == "function" then
            connection[name] = function(self, ...)
                return method(self.sock, ...)
            end
        end
    end
end

local function error_text(value)
    local ok, text = protected_call(stringify, value)
    if ok then
        return text
    end
    return "unknown error"
end

local function best_effort_close(peer)
    if peer == nil then
        return
    end
    protected_call(function()
        local close = peer.close
        if type(close) == "function" then
            close(peer)
        end
    end)
end

local function tcp(params)
    local configured = tls_parameters(params)
    return function()
        local created, raw_socket, creation_error = extended_protected_call(
            function()
                return socket.tcp()
            end,
            function(error_value)
                return error_value
            end
        )
        if not created then
            return nil, "TCP socket creation failed: " .. error_text(raw_socket)
        end
        if not raw_socket then
            return nil, "TCP socket creation failed: " .. error_text(creation_error)
        end

        local raw_metatable = getmetatable(raw_socket)
        local raw_methods = raw_metatable and raw_metatable.__index
        local raw_settimeout = type(raw_methods) == "table" and raw_methods.settimeout or nil
        if type(raw_settimeout) ~= "function" then
            best_effort_close(raw_socket)
            return nil, "TCP socket has no settimeout method"
        end

        local connection = {sock = raw_socket}

        -- Expose an idempotent, non-throwing close before socket.http calls
        -- settimeout/connect. Every failure path below closes whichever raw or
        -- TLS socket currently owns the connection.
        function connection:close()
            local current_socket = self.sock
            self.sock = nil
            best_effort_close(current_socket)
            return 1
        end

        function connection:settimeout(...)
            if not self.sock then
                return nil, "closed"
            end
            local called, result, timeout_error = extended_protected_call(
                function()
                    return raw_settimeout(self.sock, M.TIMEOUT)
                end,
                function(error_value)
                    return error_value
                end
            )
            if not called or not result then
                self:close()
                return nil,
                    "TCP timeout setup failed: "
                        .. error_text(called and timeout_error or result)
            end
            return result, timeout_error
        end

        function connection:connect(host, port)
            if not self.sock then
                return nil, "closed"
            end
            local connected, connection_error = extended_protected_call(
                function()
                    local normalized_ip = normalized_ip_bytes(host)
                    if looks_like_ip_literal(host) and not normalized_ip then
                        raise("invalid or ambiguous IP literal: " .. error_text(host), 0)
                    end

                    local raw_connected, raw_connect_error = self.sock:connect(host, port)
                    if not raw_connected then
                        raise("TCP connect failed: " .. error_text(raw_connect_error), 0)
                    end

                    local tls_socket, wrap_error = ssl.wrap(self.sock, configured)
                    if not tls_socket then
                        raise("TLS wrap failed: " .. error_text(wrap_error), 0)
                    end
                    self.sock = tls_socket

                    if not normalized_ip then
                        local sni_result, sni_error = self.sock:sni(host)
                        -- LuaSec returns no values on SNI success. False or a
                        -- second return value is therefore an explicit failure.
                        if sni_result == false or sni_error ~= nil then
                            raise("TLS SNI setup failed: " .. error_text(sni_error), 0)
                        end
                    end

                    local timeout_ok, timeout_error = self.sock:settimeout(M.TIMEOUT)
                    if not timeout_ok then
                        raise("TLS timeout setup failed: " .. error_text(timeout_error), 0)
                    end

                    local handshake_ok, handshake_error = self.sock:dohandshake()
                    if handshake_ok ~= true then
                        raise("TLS handshake failed: " .. error_text(handshake_error), 0)
                    end

                    local peer_verified, verification_error = self.sock:getpeerverification()
                    if peer_verified ~= true then
                        raise(
                            "TLS peer verification failed: " .. error_text(verification_error),
                            0
                        )
                    end

                    local certificate, certificate_error = self.sock:getpeercertificate()
                    if not certificate then
                        raise(
                            "TLS peer certificate is unavailable: "
                                .. error_text(certificate_error),
                            0
                        )
                    end
                    if not certificate_matches_host(certificate, host) then
                        raise("TLS hostname verification failed for " .. error_text(host), 0)
                    end

                    register_socket_methods(self)
                end,
                function(error_value)
                    return error_value
                end
            )
            if not connected then
                self:close()
                return nil, error_text(connection_error)
            end
            return 1
        end

        return connection
    end
end

local function default_https_port(value)
    return url.build(url.parse(value, {port = M.PORT}))
end

local function string_request(value, body, result)
    local request = {
        url = default_https_port(value),
        method = body and "POST" or "GET",
        sink = ltn12.sink.table(result),
    }
    if body then
        request.source = ltn12.source.string(body)
        request.headers = {
            ["content-length"] = #body,
            ["content-type"] = "application/x-www-form-urlencoded",
        }
    end
    return request
end

local function request(request_value, body)
    local result = {}
    local returns_string = type(request_value) == "string"
    local request_table
    if returns_string then
        request_table = string_request(request_value, body, result)
    else
        if type(request_value) ~= "table" then
            return nil, "request URL or table expected"
        end
        request_table = {}
        for key, value in pairs(request_value) do
            request_table[key] = value
        end
        request_table.url = default_https_port(request_table.url)
    end

    if http.PROXY or request_table.proxy then
        return nil, "proxy not supported"
    elseif request_table.redirect ~= nil and request_table.redirect ~= false then
        return nil, "redirect not supported"
    elseif request_table.create then
        return nil, "create function not permitted"
    end

    -- LuaSocket follows redirects when this field is absent.  Pin it to false
    -- so every certificate identity checked by this request is the identity
    -- the caller named, rather than an implicit second destination.
    request_table.redirect = false
    request_table.create = tcp(request_table)
    local ok, code, headers, status = http.request(request_table)
    if ok and returns_string then
        return table.concat(result), code, headers, status
    end
    return ok, code, headers, status
end

M.request = request
M.tcp = tcp
M._certificate_matches_host = certificate_matches_host
M._dns_name_matches = dns_name_matches
M._normalized_ip_bytes = normalized_ip_bytes
M._looks_like_ip_literal = looks_like_ip_literal

return M
