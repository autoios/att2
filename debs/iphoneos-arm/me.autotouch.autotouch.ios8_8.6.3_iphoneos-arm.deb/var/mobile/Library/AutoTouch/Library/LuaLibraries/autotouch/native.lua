-- Native safety facades are initialized and sanitized entirely in the host C
-- runtime. No Lua chunk receives the raw loader capability.

local M = {}

function M.load(module_name, entry_point)
    assert(type(module_name) == "string" and module_name ~= "", "invalid native module name")
    assert(type(entry_point) == "string" and entry_point ~= "", "invalid native entry point")
    error("native facade loader capability is unavailable", 2)
end

return M
