-- The host replaces the legacy decrypt entry point with a zero-upvalue C
-- validator before this table becomes visible to Lua. Keeping the raw pointer
-- in host state prevents debug.getupvalue from recovering it.
local native_loader = assert(..., "des56 requires the host native facade loader")
local des56 = native_loader.load("des56", "luaopen_des56")
assert(type(des56.decrypt) == "function", "des56 has no decrypt function")

return des56
