-- The packaged legacy Lua-cURL binary has unsafe POSTFIELDS length handling
-- and assertion-based callback state transitions.  Keep the file installed
-- for package compatibility, but do not expose its native API until a pinned,
-- reproducibly built replacement passes the safety suite.

error(
    "lcurl is disabled: the packaged legacy native module is not memory-safe; use socket.http or autotouch.https",
    2
)
