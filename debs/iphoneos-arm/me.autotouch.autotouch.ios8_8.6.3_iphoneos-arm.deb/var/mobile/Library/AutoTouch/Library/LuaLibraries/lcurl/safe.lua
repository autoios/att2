-- lcurl.safe shares the same native implementation as lcurl and therefore
-- cannot make the legacy POSTFIELDS/callback defects safe.

error(
    "lcurl.safe is disabled: the packaged legacy native module is not memory-safe; use socket.http or autotouch.https",
    2
)
