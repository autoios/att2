-- First-party safety facade for the packaged lsqlite3 module.  Normal database
-- ownership stays inside one Lua state; raw sqlite3* transfer, mutation of
-- SQLite's process-global temporary directory, and the legacy scalar/aggregate
-- callback APIs with process-global per-state metadata are unavailable.

local native_loader = assert(..., "lsqlite3 requires the host native facade loader")
local sqlite3 = native_loader.load("lsqlite3", "luaopen_lsqlite3")

local function disabled_pointer_api()
    error("lsqlite3 raw pointer transfer is disabled because ownership cannot be verified", 2)
end

local function disabled_temp_directory()
    error("lsqlite3.temp_directory is disabled because the legacy native implementation is unsafe", 2)
end

local function disabled_create_function()
    error("lsqlite3.create_function is disabled because the legacy binding stores per-state callback metadata process-globally", 2)
end

local function disabled_create_aggregate()
    error("lsqlite3.create_aggregate is disabled because the legacy binding stores per-state callback metadata process-globally", 2)
end

-- The module table has a readonly __newindex metamethod, so use rawset for the
-- two existing keys. CRUD, statements, backup, collations, and ordinary
-- database close/GC behavior remain available.
rawset(sqlite3, "open_ptr", disabled_pointer_api)
rawset(sqlite3, "temp_directory", disabled_temp_directory)

-- All database userdata share this native metatable.  Obtain it from a private
-- in-memory handle, replace get_ptr once, and close the probe immediately.
local probe, open_code, open_error = sqlite3.open_memory()
if not probe then
    error(
        "lsqlite3 safety facade could not initialize: "
            .. tostring(open_error or open_code),
        2
    )
end
local database_metatable = getmetatable(probe)
if type(database_metatable) ~= "table" then
    probe:close()
    error("lsqlite3 safety facade could not inspect the database API", 2)
end
rawset(database_metatable, "get_ptr", disabled_pointer_api)
rawset(database_metatable, "create_function", disabled_create_function)
rawset(database_metatable, "create_aggregate", disabled_create_aggregate)
probe:close()

return sqlite3
