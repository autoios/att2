-- The host replaces the legacy decrypt entry point with a zero-upvalue C
-- validator before this table becomes visible to Lua. Keeping the raw pointer
-- in host state prevents debug.getupvalue from recovering it.
local native_loader = assert(..., "md5.core requires the host native facade loader")
local core = native_loader.load("md5.core", "luaopen_md5_core")
assert(type(core.decrypt) == "function", "md5.core has no decrypt function")

return core
