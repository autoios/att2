json = require "json"
local _M = {}

function _M.read(plistFilePath)
	local jsonString = plistFileToJsonString(plistFilePath);
	return json.decode(jsonString);
end

function _M.write(luaTable, plistFilePath, format)
	local jsonString = json.encode(luaTable);
	return jsonStringToPlistFile(jsonString, plistFilePath, format);
end

function _M.load(plistString)
	local jsonString = plistStringToJsonString(plistString);
	return json.decode(jsonString);
end

function _M.dump(luaTable, format)
	local jsonString = json.encode(luaTable);
	return jsonStringToPlistString(jsonString, format);
end

return _M