-----------------------------------------------------------------------------
-- AutoTouch secure compatibility facade for the conventional LuaSec module.
--
-- Keep require("ssl.https") source-compatible while routing every request and
-- tcp() factory through the same peer-chain and hostname-verifying policy as
-- require("autotouch.https"). There is deliberately no insecure opt-out.
-----------------------------------------------------------------------------

return require("autotouch.https")
