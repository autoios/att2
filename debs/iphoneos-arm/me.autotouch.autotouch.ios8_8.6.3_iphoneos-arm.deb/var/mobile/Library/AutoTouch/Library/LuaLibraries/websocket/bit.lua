-- Keep this source parseable by Lua 5.1/5.2 while supporting the bundled Lua
-- 5.3 runtime, where neither the compatibility bit32 library nor LuaBitOp is
-- guaranteed to be registered. Native bitwise syntax therefore lives in a
-- dynamically compiled chunk and is only selected when that syntax exists.
local function compatible_backend(candidate)
  if type(candidate) ~= 'table' then return nil end
  local rol = candidate.rol or candidate.lrotate
  local ror = candidate.ror or candidate.rrotate
  if type(candidate.band) ~= 'function'
    or type(candidate.bor) ~= 'function'
    or type(candidate.bxor) ~= 'function'
    or type(candidate.bnot) ~= 'function'
    or type(candidate.lshift) ~= 'function'
    or type(candidate.rshift) ~= 'function'
    or type(rol) ~= 'function'
    or type(ror) ~= 'function'
  then
    return nil
  end
  return {
    band = candidate.band,
    bor = candidate.bor,
    bxor = candidate.bxor,
    bnot = candidate.bnot,
    lshift = candidate.lshift,
    rshift = candidate.rshift,
    rol = rol,
    ror = ror,
  }
end

local has_bit32,bit32 = pcall(require,'bit32')
local backend = has_bit32 and compatible_backend(bit32)
if backend then return backend end

local has_bit,bit = pcall(require,'bit')
backend = has_bit and compatible_backend(bit)
if backend then return backend end

local loader = loadstring or load
local native_chunk,native_compile_error = loader([=[
local MASK = 0xffffffff
local select = select
local tointeger = math.tointeger

local function checked_integer(value)
  local integer = tointeger(value)
  if integer == nil then
    error('number has no integer representation',3)
  end
  return integer
end

local function band(...)
  local value = MASK
  for index = 1,select('#',...) do
    value = value & select(index,...)
  end
  return value & MASK
end

local function bor(...)
  local value = 0
  for index = 1,select('#',...) do
    value = value | select(index,...)
  end
  return value & MASK
end

local function bxor(...)
  local value = 0
  for index = 1,select('#',...) do
    value = value ~ select(index,...)
  end
  return value & MASK
end

local function bnot(value)
  return (~value) & MASK
end

local function lshift(value,displacement)
  value = value & MASK
  displacement = checked_integer(displacement)
  if displacement < 0 then
    displacement = -displacement
    if displacement >= 32 then return 0 end
    return value >> displacement
  end
  if displacement >= 32 then return 0 end
  return (value << displacement) & MASK
end

local function rshift(value,displacement)
  value = value & MASK
  displacement = checked_integer(displacement)
  if displacement < 0 then
    displacement = -displacement
    if displacement >= 32 then return 0 end
    return (value << displacement) & MASK
  end
  if displacement >= 32 then return 0 end
  return value >> displacement
end

local function rol(value,displacement)
  value = value & MASK
  displacement = checked_integer(displacement) % 32
  if displacement == 0 then return value end
  return ((value << displacement) | (value >> (32 - displacement))) & MASK
end

local function ror(value,displacement)
  return rol(value,-checked_integer(displacement))
end

return {
  band = band,
  bor = bor,
  bxor = bxor,
  bnot = bnot,
  lshift = lshift,
  rshift = rshift,
  rol = rol,
  ror = ror,
}
]=],'@websocket.bit.native')

if native_chunk then
  local native_ok,native_backend = pcall(native_chunk)
  if native_ok then
    backend = compatible_backend(native_backend)
    if backend then return backend end
  else
    native_compile_error = native_backend
  end
end

error('websocket.bit requires bit32, LuaBitOp, or Lua 5.3 native bitwise operators: '
  ..tostring(native_compile_error),2)
