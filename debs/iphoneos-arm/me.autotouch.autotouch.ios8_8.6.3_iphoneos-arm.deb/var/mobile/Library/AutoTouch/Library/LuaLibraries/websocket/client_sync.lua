local socket = require'socket'
local sync = require'websocket.sync'
local tools = require'websocket.tools'

local new = function(ws)
  ws =  ws or {}
  local self = {}
  local timeout = ws.timeout == nil and 60 or ws.timeout
  if type(timeout) ~= 'number'
    or timeout ~= timeout
    or timeout <= 0
    or timeout > 300
  then
    error('websocket timeout must be a finite number between 0 and 300 seconds')
  end
  self.timeout = timeout
  local max_message_size = ws.max_message_size == nil and 8 * 1024 * 1024
    or ws.max_message_size
  if type(max_message_size) ~= 'number'
    or max_message_size ~= max_message_size
    or max_message_size % 1 ~= 0
    or max_message_size < 1
    or max_message_size > 64 * 1024 * 1024
  then
    error('max_message_size must be an integer between 1 and 67108864 bytes')
  end
  self.max_message_size = max_message_size
  
  self.sock_connect = function(self,host,port)
    self.sock = socket.tcp()
    local timeout_ok,timeout_err = self.sock:settimeout(timeout)
    if not timeout_ok then
      self.sock:close()
      return nil,timeout_err
    end
    local _,err = self.sock:connect(host,port)
    if err then
      self.sock:close()
      return nil,err
    end
  end
  
  self.sock_send = function(self,...)
    return self.sock:send(...)
  end
  
  self.sock_receive = function(self,...)
    return self.sock:receive(...)
  end
  
  self.sock_close = function(self)
    --self.sock:shutdown() Causes errors?
    self.sock:close()
  end
  
  self = sync.extend(self)
  return self
end

return new
