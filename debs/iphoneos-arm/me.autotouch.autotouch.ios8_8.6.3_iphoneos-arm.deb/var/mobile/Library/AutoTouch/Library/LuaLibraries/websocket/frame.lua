-- Following Websocket RFC: http://tools.ietf.org/html/rfc6455
local bit = require'websocket.bit'
local band = bit.band
local bxor = bit.bxor
local bor = bit.bor
local tremove = table.remove
local srep = string.rep
local ssub = string.sub
local sbyte = string.byte
local schar = string.char
local band = bit.band
local rshift = bit.rshift
local tinsert = table.insert
local tconcat = table.concat
local mmin = math.min
local mfloor = math.floor
local unpack = unpack or table.unpack
local tools = require'websocket.tools'
local write_int8 = tools.write_int8
local write_int16 = tools.write_int16
local write_int32 = tools.write_int32
local read_int8 = tools.read_int8
local read_int16 = tools.read_int16
local read_int32 = tools.read_int32

local bits = function(...)
  local n = 0
  for _,bitn in pairs{...} do
    n = n + 2^bitn
  end
  return n
end

local bit_7 = bits(7)
local bit_4_6 = bits(4,5,6)
local bit_0_3 = bits(0,1,2,3)
local bit_0_6 = bits(0,1,2,3,4,5,6)

local known_opcodes = {
  [0] = true, -- CONTINUATION
  [1] = true, -- TEXT
  [2] = true, -- BINARY
  [8] = true, -- CLOSE
  [9] = true, -- PING
  [10] = true, -- PONG
}

local is_control_opcode = function(opcode)
  return opcode >= 8
end

local checked_opcode = function(opcode)
  if type(opcode) ~= 'number'
    or opcode ~= mfloor(opcode)
    or not known_opcodes[opcode]
  then
    error('invalid WebSocket opcode: '..tostring(opcode),3)
  end
  return opcode
end

-- RFC 3629 validation used by RFC 6455 text messages and close reasons.  The
-- bundled runtime cannot assume that Lua's optional utf8 library is present,
-- so keep this validator self-contained and reject overlong encodings,
-- surrogate code points, truncated sequences, and values above U+10FFFF.
local is_valid_utf8 = function(value)
  if type(value) ~= 'string' then return false end
  local i = 1
  local length = #value
  while i <= length do
    local first = sbyte(value,i)
    if first <= 0x7f then
      i = i + 1
    elseif first >= 0xc2 and first <= 0xdf then
      local second = sbyte(value,i + 1)
      if not second or second < 0x80 or second > 0xbf then return false end
      i = i + 2
    elseif first >= 0xe0 and first <= 0xef then
      local second = sbyte(value,i + 1)
      local third = sbyte(value,i + 2)
      if not second or not third
        or third < 0x80 or third > 0xbf
        or (first == 0xe0 and (second < 0xa0 or second > 0xbf))
        or (first == 0xed and (second < 0x80 or second > 0x9f))
        or (first ~= 0xe0 and first ~= 0xed
          and (second < 0x80 or second > 0xbf))
      then
        return false
      end
      i = i + 3
    elseif first >= 0xf0 and first <= 0xf4 then
      local second = sbyte(value,i + 1)
      local third = sbyte(value,i + 2)
      local fourth = sbyte(value,i + 3)
      if not second or not third or not fourth
        or third < 0x80 or third > 0xbf
        or fourth < 0x80 or fourth > 0xbf
        or (first == 0xf0 and (second < 0x90 or second > 0xbf))
        or (first == 0xf4 and (second < 0x80 or second > 0x8f))
        or (first ~= 0xf0 and first ~= 0xf4
          and (second < 0x80 or second > 0xbf))
      then
        return false
      end
      i = i + 4
    else
      return false
    end
  end
  return true
end

local is_valid_close_code = function(code)
  if type(code) ~= 'number' or code ~= mfloor(code) then
    return false
  end
  if code >= 3000 and code < 5000 then return true end
  return code >= 1000
    and code <= 1014
    and code ~= 1004
    and code ~= 1005
    and code ~= 1006
end

-- TODO: improve performance
local xor_mask = function(encoded,mask,payload)
  local transformed,transformed_arr = {},{}
  -- xor chunk-wise to prevent stack overflow.
  -- sbyte and schar multiple in/out values
  -- which require stack
  for p=1,payload,2000 do
    local last = mmin(p+1999,payload)
    local original = {sbyte(encoded,p,last)}
    for i=1,#original do
      local j = (i-1) % 4 + 1
      transformed[i] = bxor(original[i],mask[j])
    end
    local xored = schar(unpack(transformed,1,#original))
    tinsert(transformed_arr,xored)
  end
  return tconcat(transformed_arr)
end

local encode_header_small = function(header, payload)
  return schar(header, payload)
end

local encode_header_medium = function(header, payload, len)
  return schar(header, payload, band(rshift(len, 8), 0xFF), band(len, 0xFF))
end

local encode_header_big = function(header, payload, high, low)
  return schar(header, payload)..write_int32(high)..write_int32(low)
end

local encode = function(data,opcode,masked,fin)
  if type(data) ~= 'string' then
    error('WebSocket payload must be a string',2)
  end
  opcode = checked_opcode(opcode or 1) -- TEXT is the default opcode
  if fin ~= nil and type(fin) ~= 'boolean' then
    error('WebSocket FIN flag must be a boolean',2)
  end
  local is_final = fin == nil or fin == true
  local len = #data
  if is_control_opcode(opcode) and (not is_final or len > 125) then
    error('WebSocket control frames must be final and at most 125 bytes',2)
  end

  local header = opcode
  if is_final then
    header = bor(header,bit_7)
  end
  local payload = 0
  if masked then
    payload = bor(payload,bit_7)
  end
  local chunks = {}
  if len < 126 then
    payload = bor(payload,len)
    tinsert(chunks,encode_header_small(header,payload))
  elseif len <= 0xffff then
    payload = bor(payload,126)
    tinsert(chunks,encode_header_medium(header,payload,len))
  elseif len <= 2^53 then
    local high = mfloor(len/2^32)
    local low = len - high*2^32
    payload = bor(payload,127)
    tinsert(chunks,encode_header_big(header,payload,high,low))
  else
    error('WebSocket payload is too large to encode safely',2)
  end
  if not masked then
    tinsert(chunks,data)
  else
    local random_mask = tools.random_bytes(4)
    local m1,m2,m3,m4 = sbyte(random_mask,1,4)
    local mask = {m1,m2,m3,m4}
    tinsert(chunks,random_mask)
    tinsert(chunks,xor_mask(data,mask,#data))
  end
  return tconcat(chunks)
end

local decode = function(encoded)
  if type(encoded) ~= 'string' then
    error('WebSocket frame input must be a string',2)
  end
  local encoded_bak = encoded
  if #encoded < 2 then
    return nil,2-#encoded
  end
  local pos,header,payload
  pos,header = read_int8(encoded,1)
  pos,payload = read_int8(encoded,pos)
  local high,low
  encoded = ssub(encoded,pos)
  local bytes = 2
  local fin = band(header,bit_7) > 0
  local opcode = band(header,bit_0_3)
  if band(header,bit_4_6) ~= 0 then
    error('WebSocket RSV bits require a negotiated extension',2)
  end
  checked_opcode(opcode)
  local mask = band(payload,bit_7) > 0
  payload = band(payload,bit_0_6)
  if is_control_opcode(opcode) and (not fin or payload > 125) then
    error('WebSocket control frames must be final and at most 125 bytes',2)
  end
  if payload > 125 then
    if payload == 126 then
      if #encoded < 2 then
        return nil,2-#encoded
      end
      pos,payload = read_int16(encoded,1)
      if payload < 126 then
        error('WebSocket frame used a non-minimal 16-bit payload length',2)
      end
    elseif payload == 127 then
      if #encoded < 8 then
        return nil,8-#encoded
      end
      pos,high = read_int32(encoded,1)
      pos,low = read_int32(encoded,pos)
      if high < 0 then high = high + 2^32 end
      if low < 0 then low = low + 2^32 end
      if high >= 0x80000000 then
        error('WebSocket 64-bit payload length has its reserved bit set',2)
      end
      payload = high*2^32 + low
      if payload < 0x10000 then
        error('WebSocket frame used a non-minimal 64-bit payload length',2)
      end
      if payload > 2^53 then
        error('WebSocket payload length exceeds the safe integer range',2)
      end
    else
      error('invalid WebSocket payload length marker',2)
    end
    encoded = ssub(encoded,pos)
    bytes = bytes + pos - 1
  end
  local decoded
  if mask then
    local bytes_short = payload + 4 - #encoded
    if bytes_short > 0 then
      return nil,bytes_short
    end
    local m1,m2,m3,m4
    pos,m1 = read_int8(encoded,1)
    pos,m2 = read_int8(encoded,pos)
    pos,m3 = read_int8(encoded,pos)
    pos,m4 = read_int8(encoded,pos)
    encoded = ssub(encoded,pos)
    local mask_key = {
      m1,m2,m3,m4
    }
    decoded = xor_mask(encoded,mask_key,payload)
    bytes = bytes + 4 + payload
  else
    local bytes_short = payload - #encoded
    if bytes_short > 0 then
      return nil,bytes_short
    end
    if #encoded > payload then
      decoded = ssub(encoded,1,payload)
    else
      decoded = encoded
    end
    bytes = bytes + payload
  end
  return decoded,fin,opcode,encoded_bak:sub(bytes+1),mask
end

local encode_close = function(code,reason)
  if code == nil then
    if reason ~= nil and tostring(reason) ~= '' then
      error('WebSocket close reason requires a status code',2)
    end
    return ''
  end
  if not is_valid_close_code(code) then
    error('invalid WebSocket close status code: '..tostring(code),2)
  end
  local normalized_reason = reason == nil and '' or tostring(reason)
  if not is_valid_utf8(normalized_reason) then
    error('WebSocket close reason must be valid UTF-8',2)
  end
  if #normalized_reason > 123 then
    error('WebSocket close reason must be at most 123 bytes',2)
  end
  return write_int16(code)..normalized_reason
end

local validate_close_payload = function(data)
  if type(data) ~= 'string' then
    return false,nil,nil,1002,'WebSocket close payload must be a string'
  end
  if #data == 0 then return true,nil,nil end
  if #data == 1 then
    return false,nil,nil,1002,'WebSocket close frame has an invalid one-byte payload'
  end
  local _,code = read_int16(data,1)
  if not is_valid_close_code(code) then
    return false,code,nil,1002,
      'invalid WebSocket close status code: '..tostring(code)
  end
  local reason = data:sub(3)
  if not is_valid_utf8(reason) then
    return false,code,reason,1007,'WebSocket close reason must be valid UTF-8'
  end
  return true,code,reason
end

local decode_close = function(data)
  local valid,code,reason,_,validation_error = validate_close_payload(data or '')
  if not valid then
    error(validation_error,2)
  end
  return code,reason
end

return {
  encode = encode,
  decode = decode,
  encode_close = encode_close,
  decode_close = decode_close,
  validate_close_payload = validate_close_payload,
  is_valid_close_code = is_valid_close_code,
  is_valid_utf8 = is_valid_utf8,
  encode_header_small = encode_header_small,
  encode_header_medium = encode_header_medium,
  encode_header_big = encode_header_big,
  CONTINUATION = 0,
  TEXT = 1,
  BINARY = 2,
  CLOSE = 8,
  PING = 9,
  PONG = 10
}
