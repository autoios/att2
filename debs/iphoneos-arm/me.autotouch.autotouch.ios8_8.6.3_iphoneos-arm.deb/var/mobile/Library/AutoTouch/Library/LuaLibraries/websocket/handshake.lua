local sha1 = require'websocket.tools'.sha1
local base64 = require'websocket.tools'.base64
local tinsert = table.insert

local guid = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

local is_http_token = function(value)
  return type(value) == 'string'
    and value ~= ''
    and value:match("^[!#$%%&'*+%.%^_`|~0-9A-Za-z%-]+$") ~= nil
end

local has_forbidden_control = function(value,allow_tab)
  for index = 1,#value do
    local byte = string.byte(value,index)
    if (byte < 32 and not (allow_tab and byte == 9)) or byte == 127 then
      return true
    end
  end
  return false
end

local checked_request_value = function(value,label,allow_empty,reject_whitespace)
  if type(value) ~= 'string' or (not allow_empty and value == '') then
    error('WebSocket request '..label..' must be a non-empty string',3)
  end
  if value:find('[\r\n]') then
    error('WebSocket request '..label..' must not contain CR/LF',3)
  end
  if value:find('%c') then
    error('WebSocket request '..label..' must not contain control characters',3)
  end
  if reject_whitespace and value:find('%s') then
    error('WebSocket request '..label..' must not contain whitespace',3)
  end
  return value
end

local sec_websocket_accept = function(sec_websocket_key)
  local a = sec_websocket_key..guid
  local sha1 = sha1(a)
  assert((#sha1 % 2) == 0)
  return base64.encode(sha1)
end

local header_has_token = function(value,expected)
  if type(value) ~= 'string' then return false end
  expected = expected:lower()
  for token in value:gmatch('[^,]+') do
    token = token:match('^%s*(.-)%s*$'):lower()
    if token == expected then return true end
  end
  return false
end

local is_valid_sec_websocket_key = function(value)
  if type(value) ~= 'string' or #value ~= 24
    or value:sub(23,24) ~= '=='
    or value:sub(1,22):find('[^%w%+/]')
  then
    return false
  end
  local decoded_ok,decoded = pcall(base64.decode,value)
  return decoded_ok
    and type(decoded) == 'string'
    and #decoded == 16
    and base64.encode(decoded) == value
end

local http_headers = function(request)
  if type(request) ~= 'string' then
    return nil,'HTTP message must be a string'
  end
  local headers = {}
  local header_counts = {}
  local first_line_end = request:find('\r\n',1,true)
  local header_end = request:find('\r\n\r\n',1,true)
  if not first_line_end or not header_end or first_line_end > header_end then
    return nil,'incomplete HTTP headers'
  end
  local first_line = request:sub(1,first_line_end - 1)
  if first_line == '' or has_forbidden_control(first_line,false)
    or not first_line:match('HTTP/1%.1')
  then
    return nil,'invalid HTTP/1.1 start line'
  end
  local cursor = first_line_end + 2
  while cursor < header_end do
    local line_end = request:find('\r\n',cursor,true)
    if not line_end or line_end > header_end then
      return nil,'malformed HTTP header framing'
    end
    local line = request:sub(cursor,line_end - 1)
    local colon = line:find(':',1,true)
    if line == '' or not colon then
      return nil,'malformed HTTP header line'
    end
    local name = line:sub(1,colon - 1)
    local raw_value = line:sub(colon + 1)
    if not is_http_token(name) or has_forbidden_control(name,false)
      or has_forbidden_control(raw_value,true)
    then
      return nil,'malformed HTTP header line'
    end
    local val = raw_value:match('^[ \t]*(.-)[ \t]*$')
    name = name:lower()
    header_counts[name] = (header_counts[name] or 0) + 1
    if not name:match('sec%-websocket') then
      val = val:lower()
    end
    if not headers[name] then
      headers[name] = val
    else
      headers[name] = headers[name]..','..val
    end
    cursor = line_end + 2
  end
  if cursor ~= header_end + 2 then
    return nil,'malformed HTTP header framing'
  end
  local body = request:sub(header_end + 4)
  return headers,body,first_line,header_counts
end

local upgrade_request = function(req)
  if type(req) ~= 'table' then
    error('WebSocket upgrade request must be a table',2)
  end
  local format = string.format
  local uri = checked_request_value(req.uri or '/','URI',false,true)
  local host = checked_request_value(req.host,'host',false,true)
  local key = checked_request_value(req.key,'key',false,true)
  if uri:sub(1,1) ~= '/' or uri:find('#',1,true) then
    error('WebSocket request URI must be an absolute path without a fragment',2)
  end
  if req.port ~= nil and (type(req.port) ~= 'number'
    or req.port ~= math.floor(req.port) or req.port < 1 or req.port > 65535)
  then
    error('WebSocket request port must be an integer between 1 and 65535',2)
  end
  local protocols = req.protocols
  if protocols ~= nil and type(protocols) ~= 'table' then
    error('WebSocket request protocols must be a table',2)
  end
  for _,protocol in ipairs(protocols or {}) do
    checked_request_value(protocol,'protocol',false)
    if not is_http_token(protocol) then
      error('WebSocket request protocol must be a valid HTTP token',2)
    end
  end
  local origin
  if req.origin ~= nil then
    origin = checked_request_value(req.origin,'origin',false,true)
  end
  local lines = {
    format('GET %s HTTP/1.1',uri),
    format('Host: %s',host),
    'Upgrade: websocket',
    'Connection: Upgrade',
    format('Sec-WebSocket-Key: %s',key),
    'Sec-WebSocket-Version: 13',
  }
  if protocols and #protocols > 0 then
    tinsert(lines,format('Sec-WebSocket-Protocol: %s',table.concat(protocols,', ')))
  end
  if origin then
    tinsert(lines,string.format('Origin: %s',origin))
  end
  if req.port and req.port ~= 80 then
    lines[2] = format('Host: %s:%d',host,req.port)
  end
  tinsert(lines,'\r\n')
  return table.concat(lines,'\r\n')
end

local accept_upgrade = function(request,protocols)
  local request_target = type(request) == 'string'
    and request:match('^GET ([^%s%c]+) HTTP/1%.1\r\n')
  if not request_target or request_target:sub(1,1) ~= '/'
    or request_target:find('#',1,true)
  then
    return nil,'HTTP/1.1 400 Bad Request\r\n\r\n'
  end
  local headers,_,_,header_counts = http_headers(request)
  if type(headers) ~= 'table'
  or not header_has_token(headers['upgrade'],'websocket')
  or not header_has_token(headers['connection'],'upgrade')
  or header_counts['host'] ~= 1
  or headers['host'] == ''
  or headers['host']:find('[%s%c]')
  or header_counts['sec-websocket-key'] ~= 1
  or not is_valid_sec_websocket_key(headers['sec-websocket-key'])
  or
  headers['sec-websocket-version'] ~= '13' then
    return nil,'HTTP/1.1 400 Bad Request\r\n\r\n'
  end
  protocols = type(protocols) == 'table' and protocols or {}
  local prot
  if headers['sec-websocket-protocol'] then
    if header_counts['sec-websocket-protocol'] ~= 1 then
      return nil,'HTTP/1.1 400 Bad Request\r\n\r\n'
    end
    local offered_protocols = {}
    local value = headers['sec-websocket-protocol']
    local position = 1
    while true do
      local comma = value:find(',',position,true)
      local protocol = value:sub(position,comma and comma - 1 or #value)
        :match('^%s*(.-)%s*$')
      if not is_http_token(protocol) then
        return nil,'HTTP/1.1 400 Bad Request\r\n\r\n'
      end
      tinsert(offered_protocols,protocol)
      if not comma then break end
      position = comma + 1
    end
    for _,protocol in ipairs(offered_protocols) do
      for _,supported in ipairs(protocols) do
        if supported == protocol then
          prot = protocol
          break
        end
      end
      if prot then
        break
      end
    end
  end
  local lines = {
    'HTTP/1.1 101 Switching Protocols',
    'Upgrade: websocket',
    'Connection: Upgrade',
    string.format('Sec-WebSocket-Accept: %s',sec_websocket_accept(headers['sec-websocket-key'])),
  }
  if prot then
    tinsert(lines,string.format('Sec-WebSocket-Protocol: %s',prot))
  end
  tinsert(lines,'\r\n')
  return table.concat(lines,'\r\n'),prot
end

return {
  sec_websocket_accept = sec_websocket_accept,
  http_headers = http_headers,
  accept_upgrade = accept_upgrade,
  upgrade_request = upgrade_request,
  is_valid_protocol_token = is_http_token,
}
