
local socket = require'socket'
local copas = require'copas'
local tools = require'websocket.tools'
local frame = require'websocket.frame'
local handshake = require'websocket.handshake'
local sync = require'websocket.sync'
local tinsert = table.insert
local MAX_HANDSHAKE_BYTES = 64 * 1024
local MAX_HANDSHAKE_LINES = 200
local OPEN_CONNECTION_PAUSE_SECONDS = 0.05

local close_socket = function(sock)
  pcall(sock.close,sock)
end

local send_complete = function(sock,payload)
  local called,sent,send_error = pcall(copas.send,sock,payload)
  if not called then return nil,tostring(sent) end
  if sent ~= #payload then
    return nil,tostring(send_error or 'WebSocket handshake response was not fully sent')
  end
  return true
end

local client = function(sock,protocol,clients)
  local copas = require'copas'
  
  local self = {}
  
  self.state = 'OPEN'
  self.is_server = true
  
  self.sock_send = function(self,...)
    return copas.send(sock,...)
  end
  
  self.sock_receive = function(self,...)
    return copas.receive(sock,...)
  end
  
  self.sock_close = function(self)
    sock:shutdown()
    sock:close()
  end
  
  self = sync.extend(self)
  
  self.on_close = function(self)
    clients[protocol][self] = nil
  end
  
  self.broadcast = function(self,...)
    for client in pairs(clients[protocol]) do
      if client ~= self then
        client:send(...)
      end
    end
    self:send(...)
  end
  
  return self
end

local listen = function(opts)
  
  local copas = require'copas'
  assert(opts and (opts.protocols or opts.default))
  local on_error = opts.on_error or function(s) print(s) end
  local listener,err = socket.bind(opts.interface or '*',opts.port or 80)
  if err then
    error(err)
  end
  local protocols = {}
  local clients = {}
  if opts.protocols then
    for protocol,handler in pairs(opts.protocols) do
      if not handshake.is_valid_protocol_token(protocol) then
        error('invalid WebSocket server subprotocol: '..tostring(protocol))
      end
      if type(handler) ~= 'function' then
        error('WebSocket server protocol handler must be a function')
      end
      clients[protocol] = {}
      tinsert(protocols,protocol)
    end
  end
  if opts.default ~= nil and type(opts.default) ~= 'function' then
    error('WebSocket server default handler must be a function')
  end
  -- true is the 'magic' index for the default handler
  clients[true] = {}
  copas.addserver(
    listener,
    function(sock)
      local upgrade_request,request_error = tools.read_http_headers(
        function(bytes)
          return copas.receive(sock,bytes)
        end,
        MAX_HANDSHAKE_BYTES,
        MAX_HANDSHAKE_LINES
      )
      if not upgrade_request then
        close_socket(sock)
        if on_error then
          on_error('invalid request: '..tostring(request_error))
        end
        return
      end
      local accepted,response,protocol =
        pcall(handshake.accept_upgrade,upgrade_request,protocols)
      if not accepted or not response then
        local failure_response = accepted and protocol
          or 'HTTP/1.1 400 Bad Request\r\n\r\n'
        if type(failure_response) == 'string' then
          send_complete(sock,failure_response)
        end
        close_socket(sock)
        if on_error then
          on_error('invalid request')
        end
        return
      end
      local handler
      local new_client
      local protocol_index
      if protocol and opts.protocols[protocol] then
        protocol_index = protocol
        handler = opts.protocols[protocol]
      elseif opts.default then
        -- true is the 'magic' index for the default handler
        protocol_index = true
        handler = opts.default
      else
        send_complete(sock,'HTTP/1.1 400 Bad Request\r\n\r\n')
        close_socket(sock)
        if on_error then
          on_error('bad protocol')
        end
        return
      end
      local sent,send_error = send_complete(sock,response)
      if not sent then
        close_socket(sock)
        if on_error then
          on_error('WebSocket handshake send failed: '..tostring(send_error))
        end
        return
      end
      new_client = client(sock,protocol_index,clients)
      clients[protocol_index][new_client] = true
      local handled,handler_error = pcall(function()
        handler(new_client)
        -- Copas auto-closes an accepted socket when its handler coroutine
        -- returns. Keep that coroutine alive for handlers which transfer the
        -- client to another coroutine, but always yield through Copas' timer
        -- queue. The upstream dummy-send trick can return immediately
        -- and spin at full CPU with real Copas implementations.
        local cooperative_pause
        if type(copas.pause) == 'function' then
          cooperative_pause = copas.pause
        elseif type(copas.sleep) == 'function' then
          cooperative_pause = copas.sleep
        end
        if new_client.state ~= 'CLOSED' and cooperative_pause == nil then
          error('Copas cooperative pause API is unavailable')
        end
        while new_client.state ~= 'CLOSED' do
          cooperative_pause(OPEN_CONNECTION_PAUSE_SECONDS)
        end
      end)
      clients[protocol_index][new_client] = nil
      new_client.state = 'CLOSED'
      close_socket(sock)
      if not handled and on_error then
        on_error('WebSocket handler failed: '..tostring(handler_error))
      end
    end)
  local self = {}
  self.close = function(_,keep_clients)
    copas.removeserver(listener)
    listener = nil
    if not keep_clients then
      for _,protocol_clients in pairs(clients) do
        for client in pairs(protocol_clients) do
          client:close()
        end
      end
    end
  end
  return self
end

return {
  listen = listen
}
