local frame = require'websocket.frame'
local handshake = require'websocket.handshake'
local tools = require'websocket.tools'
local ssl = require'ssl'
local secure_https = require'autotouch.https'
local tinsert = table.insert
local tconcat = table.concat
local protected_call = pcall
local DEFAULT_MAX_MESSAGE_SIZE = 8 * 1024 * 1024
local MAX_CONFIGURED_MESSAGE_SIZE = 64 * 1024 * 1024
local MAX_HANDSHAKE_BYTES = 64 * 1024
local MAX_HANDSHAKE_LINES = 200
local SENDABLE_OPCODES = {
  [frame.TEXT] = true,
  [frame.BINARY] = true,
  [frame.PING] = true,
  [frame.PONG] = true,
}

local TLS_OPTIONS = {
  'all',
  'no_sslv2',
  'no_sslv3',
  'no_tlsv1',
  'no_tlsv1_1',
}

local DEFAULT_CA_FILES = {
  '/etc/ssl/certs/cacert.pem',
  '/etc/ssl/cert.pem',
  '/usr/local/etc/openssl/cert.pem',
  '/var/jb/etc/ssl/certs/cacert.pem',
  '/var/jb/etc/ssl/cert.pem',
}

local readable_file = function(path)
  local stream = io.open(path, 'rb')
  if not stream then return false end
  stream:close()
  return true
end

local default_ca_file = function()
  for _,path in ipairs(DEFAULT_CA_FILES) do
    if readable_file(path) then return path end
  end
end

local tls_parameters = function(params)
  if params ~= nil and type(params) ~= 'table' then
    return nil,'wss ssl_params must be a table'
  end
  local configured = {}
  for key,value in pairs(params or {}) do configured[key] = value end
  if configured.verify ~= nil and configured.verify ~= 'peer' then
    return nil,'wss does not permit disabling peer verification'
  end
  configured.mode = 'client'
  configured.protocol = 'any'
  configured.verify = 'peer'
  configured.verifyext = nil

  local options = {}
  local seen = {}
  if type(configured.options) == 'table' then
    for _,option in ipairs(configured.options) do
      if type(option) == 'string' and not seen[option] then
        options[#options + 1] = option
        seen[option] = true
      end
    end
  end
  for _,option in ipairs(TLS_OPTIONS) do
    if not seen[option] then
      options[#options + 1] = option
      seen[option] = true
    end
  end
  configured.options = options

  if not configured.cafile and not configured.capath then
    configured.cafile = default_ca_file()
    if not configured.cafile then
      return nil,'wss could not find a CA bundle; provide cafile or capath'
    end
  end
  return configured
end

local protected_socket_close = function(self)
  local called,result,err = protected_call(self.sock_close,self)
  if not called then
    return false,tostring(result)
  end
  if result == nil and err ~= nil then
    return false,tostring(err)
  end
  return true
end

local finalize_close = function(self,notify)
  local should_notify = self.state ~= 'CLOSED'
  self.state = 'CLOSED'
  self.is_closing = false
  local close_ok,close_err = protected_socket_close(self)
  if notify and should_notify and self.on_close then
    local notified,notify_err = protected_call(self.on_close,self)
    if not notified and close_ok then
      return false,tostring(notify_err)
    end
  end
  return close_ok,close_err
end

local close_reason = function(self,message,notify)
  local reason = tostring(message or 'connection failed')
  local close_ok,close_err = finalize_close(self,notify)
  if not close_ok and close_err then
    reason = reason..'; socket close failed: '..tostring(close_err)
  end
  return reason
end

local close_with_error = function(self,message,headers)
  return nil,close_reason(self,message,false),headers
end

local header_has_token = function(value,expected)
  if type(value) ~= 'string' then return false end
  expected = string.lower(expected)
  for token in string.gmatch(value,'[^,]+') do
    token = string.lower(string.match(token,'^%s*(.-)%s*$'))
    if token == expected then return true end
  end
  return false
end

local receive = function(self)
  if self.state ~= 'OPEN' and not self.is_closing then
    return nil,nil,false,1006,'wrong state'
  end
  local first_opcode
  local frames
  local message_size = 0
  local max_message_size = self.max_message_size or DEFAULT_MAX_MESSAGE_SIZE
  local bytes = 2
  local encoded = ''
  local clean = function(was_clean,code,reason)
    return nil,nil,was_clean,code,close_reason(self,reason or 'closed',true)
  end
  local reset_frame = function()
    bytes = 2
    encoded = ''
  end
  while true do
    local receive_called,chunk,err = protected_call(self.sock_receive,self,bytes)
    if not receive_called then
      return clean(false,1006,chunk)
    end
    if err or chunk == nil then
      return clean(false,1006,err or 'closed')
    end
    if type(chunk) ~= 'string' then
      return clean(false,1006,'WebSocket backend returned a non-string payload')
    end
    encoded = encoded..chunk
    local decoded_ok,decoded,fin,opcode,_,masked = protected_call(frame.decode,encoded)
    if not decoded_ok then
      return clean(false,1002,decoded)
    end
    if decoded ~= nil and self.is_server and not masked then
      return clean(false,1002,'WebSocket protocol error: client frame was not masked')
    elseif decoded ~= nil and not self.is_server and masked then
      return clean(false,1002,'WebSocket protocol error: server frame was masked')
    end
    if decoded ~= nil then
      if opcode == frame.CLOSE then
        local close_valid,code,reason,validation_code,validation_error =
          frame.validate_close_payload(decoded)
        if not close_valid then
          return clean(false,validation_code,validation_error)
        end
        if not self.is_closing then
          -- echo code
          local close_encoded,msg = protected_call(frame.encode_close,code)
          if not close_encoded then
            return clean(false,1002,msg)
          end
          local frame_encoded,close_frame = protected_call(
            frame.encode,msg,frame.CLOSE,not self.is_server
          )
          if not frame_encoded then
            return clean(false,1002,close_frame)
          end
          local send_called,n,err = protected_call(self.sock_send,self,close_frame)
          if not send_called then
            return clean(false,1006,n)
          end
          if n == #close_frame then
            return clean(true,code,reason)
          else
            return clean(false,1006,err or 'WebSocket close response was not fully sent')
          end
        else
          return decoded,opcode
        end
      elseif opcode == frame.PING then
        local frame_encoded,pong = protected_call(
          frame.encode,decoded,frame.PONG,not self.is_server
        )
        if not frame_encoded then
          return clean(false,1002,pong)
        end
        local send_called,n,err = protected_call(self.sock_send,self,pong)
        if not send_called then
          return clean(false,1006,n)
        end
        if n ~= #pong then
          return clean(false,1006,err or 'WebSocket pong was not fully sent')
        end
        reset_frame()
      elseif opcode == frame.PONG then
        -- PONG is a control response and may be interleaved with fragments.
        reset_frame()
      else
        if #decoded > max_message_size - message_size then
          return clean(false,1009,'WebSocket message exceeds configured limit')
        end
        message_size = message_size + #decoded
        if opcode == frame.CONTINUATION then
          if not frames then
            return clean(false,1002,'WebSocket continuation frame has no open message')
          end
          tinsert(frames,decoded)
          if fin then
            local message = tconcat(frames)
            if first_opcode == frame.TEXT and not frame.is_valid_utf8(message) then
              return clean(false,1007,'WebSocket text message must be valid UTF-8')
            end
            return message,first_opcode
          end
          reset_frame()
        else
          if frames then
            return clean(false,1002,'WebSocket data frame interrupted a fragmented message')
          end
          first_opcode = opcode
          if fin then
            if first_opcode == frame.TEXT and not frame.is_valid_utf8(decoded) then
              return clean(false,1007,'WebSocket text message must be valid UTF-8')
            end
            return decoded,first_opcode
          end
          frames = {decoded}
          reset_frame()
        end
      end
    else
      if type(fin) ~= 'number' or fin <= 0 then
        return clean(false,1002,'WebSocket decoder returned an invalid byte request')
      end
      if #encoded + fin > max_message_size + 14 then
        return clean(false,1009,'WebSocket frame exceeds configured limit')
      end
      bytes = fin
    end
  end
  assert(false,'never reach here')
end

local send = function(self,data,opcode)
  if self.state ~= 'OPEN' then
    return nil,false,1006,'wrong state'
  end
  if type(data) ~= 'string' then
    return nil,false,1003,'WebSocket payload must be a string'
  end
  if #data > (self.max_message_size or DEFAULT_MAX_MESSAGE_SIZE) then
    return nil,false,1009,'WebSocket message exceeds configured limit'
  end
  local selected_opcode = opcode or frame.TEXT
  if not SENDABLE_OPCODES[selected_opcode] then
    return nil,false,1002,
      'WebSocket send() supports only TEXT, BINARY, PING, or PONG; use close() for CLOSE'
  end
  if selected_opcode == frame.TEXT and not frame.is_valid_utf8(data) then
    return nil,false,1007,'WebSocket text message must be valid UTF-8'
  end
  local frame_encoded,encoded = protected_call(
    frame.encode,data,selected_opcode,not self.is_server
  )
  if not frame_encoded then
    return nil,false,1002,tostring(encoded)
  end
  local send_called,n,err = protected_call(self.sock_send,self,encoded)
  if not send_called then
    return nil,false,1006,close_reason(self,n,true)
  end
  if n ~= #encoded then
    return nil,false,1006,close_reason(
      self,err or 'WebSocket frame was not fully sent',true
    )
  end
  return true
end

local close = function(self,code,reason)
  if self.state ~= 'OPEN' then
    return false,1006,'wrong state'
  end
  local selected_code = code or 1000
  if not frame.is_valid_close_code(selected_code) then
    return false,1002,'invalid WebSocket close status code: '..tostring(selected_code)
  end
  if reason ~= nil and not frame.is_valid_utf8(tostring(reason)) then
    return false,1007,'WebSocket close reason must be valid UTF-8'
  end
  local close_encoded,msg = protected_call(frame.encode_close,selected_code,reason)
  if not close_encoded then
    return false,1002,tostring(msg)
  end
  local frame_encoded,encoded = protected_call(
    frame.encode,msg,frame.CLOSE,not self.is_server
  )
  if not frame_encoded then
    return false,1002,tostring(encoded)
  end
  local send_called,n,err = protected_call(self.sock_send,self,encoded)
  if not send_called then
    return false,1006,close_reason(self,n,true)
  end
  if n ~= #encoded then
    return false,1006,close_reason(
      self,err or 'WebSocket close frame was not fully sent',true
    )
  end
  local was_clean = false
  local result_code = 1005
  local result_reason = ''
  self.is_closing = true
  self.state = 'CLOSING'
  local rmsg,opcode,receive_clean,receive_code,receive_reason = self:receive()
  if rmsg ~= nil and opcode == frame.CLOSE then
    local close_decoded
    close_decoded,result_code,result_reason = protected_call(frame.decode_close,rmsg)
    if close_decoded then
      was_clean = true
    else
      result_reason = tostring(result_code)
      result_code = 1002
    end
  elseif self.state == 'CLOSED' then
    return receive_clean or false,receive_code or 1006,receive_reason or 'closed'
  else
    result_code = 1002
    result_reason = 'WebSocket peer sent data after the close handshake began'
  end
  local close_ok,close_err = finalize_close(self,true)
  if not close_ok then
    return false,1006,tostring(close_err or 'socket close failed')
  end
  return was_clean,result_code,result_reason or ''
end

local connect = function(self,ws_url,ws_protocol,ssl_params)
  if self.state ~= 'CLOSED' then
    return nil,'wrong state',nil
  end
  self.is_closing = false
  local parsed,protocol,host,port,uri,host_header = protected_call(tools.parse_url,ws_url)
  if not parsed then
    return nil,tostring(protocol),nil
  end
  if protocol ~= 'ws' and protocol ~= 'wss' then
    return nil,'bad protocol',nil
  end
  local connection_timeout = self.timeout or 60
  if type(connection_timeout) ~= 'number'
    or connection_timeout ~= connection_timeout
    or connection_timeout <= 0
    or connection_timeout > 300
  then
    return nil,'websocket timeout must be a finite number in (0, 300] seconds',nil
  end
  local max_message_size = self.max_message_size or DEFAULT_MAX_MESSAGE_SIZE
  if type(max_message_size) ~= 'number'
    or max_message_size ~= max_message_size
    or max_message_size % 1 ~= 0
    or max_message_size < 1
    or max_message_size > MAX_CONFIGURED_MESSAGE_SIZE
  then
    return nil,'max_message_size must be an integer between 1 and 67108864 bytes',nil
  end
  self.max_message_size = max_message_size
  local ws_protocols_tbl = {}
  if type(ws_protocol) == 'string' then
      ws_protocols_tbl = {ws_protocol}
  elseif type(ws_protocol) == 'table' then
      ws_protocols_tbl = ws_protocol
  elseif ws_protocol ~= nil then
      return nil,'WebSocket protocol must be a string or table',nil
  end
  local offered_protocols = {}
  for _,offered_protocol in ipairs(ws_protocols_tbl) do
    if not handshake.is_valid_protocol_token(offered_protocol) then
      return nil,'Invalid WebSocket subprotocol',nil
    end
    offered_protocols[offered_protocol] = true
  end
  local configured
  if protocol == 'wss' then
    local configure_err
    configured,configure_err = tls_parameters(ssl_params)
    if not configured then
      return nil,configure_err,nil
    end
  end
  -- Preconnect (for SSL if needed)
  local connected,connect_result,err = protected_call(self.sock_connect,self,host,port)
  if not connected then
    return close_with_error(self,connect_result)
  elseif err then
    return close_with_error(self,err)
  end
  if protocol == 'wss' then
    local wrapped,tls_socket,wrap_err = protected_call(ssl.wrap,self.sock,configured)
    if not wrapped then
      return close_with_error(self,tls_socket)
    elseif not tls_socket then
      return close_with_error(self,wrap_err or 'TLS wrap failed')
    end
    self.sock = tls_socket

    local timeout_called,timeout_result,timeout_err =
      protected_call(self.sock.settimeout,self.sock,connection_timeout)
    if not timeout_called or not timeout_result then
      return close_with_error(
        self,timeout_called and timeout_err or timeout_result
      )
    end

    local normalized_ip = secure_https._normalized_ip_bytes(host)
    if secure_https._looks_like_ip_literal(host) and not normalized_ip then
      return close_with_error(self,'invalid or ambiguous IP literal: '..tostring(host))
    end
    if not normalized_ip then
      local sni_called,sni_result,sni_err = protected_call(self.sock.sni,self.sock,host)
      if not sni_called or sni_result == false or sni_err ~= nil then
        return close_with_error(self,sni_called and sni_err or sni_result)
      end
    end

    local handshook,handshake_result,handshake_err =
      protected_call(self.sock.dohandshake,self.sock)
    if not handshook or handshake_result ~= true then
      return close_with_error(
        self,
        handshook and handshake_err or handshake_result
      )
    end

    local verified,peer_verified,verification_err =
      protected_call(self.sock.getpeerverification,self.sock)
    if not verified or peer_verified ~= true then
      return close_with_error(
        self,
        verified and verification_err or peer_verified
      )
    end

    local got_certificate,certificate,certificate_err =
      protected_call(self.sock.getpeercertificate,self.sock)
    if not got_certificate or not certificate then
      return close_with_error(
        self,
        got_certificate and certificate_err or certificate
      )
    end
    local matched,host_matches = protected_call(
      secure_https._certificate_matches_host,certificate,host
    )
    if not matched or host_matches ~= true then
      return close_with_error(self,'TLS hostname verification failed for '..tostring(host))
    end
  end
  local key_generated,key = protected_call(tools.generate_key)
  if not key_generated or type(key) ~= 'string' then
    return close_with_error(self,key,nil)
  end
  local request_built,req = protected_call(handshake.upgrade_request,{
      key = key,
      host = host_header or host,
      port = port,
      protocols = ws_protocols_tbl,
      uri = uri
    })
  if not request_built or type(req) ~= 'string' then
    return close_with_error(self,req,nil)
  end
  local send_called,n,err = protected_call(self.sock_send,self,req)
  if not send_called then
    return close_with_error(self,n,nil)
  elseif n ~= #req then
    return close_with_error(self,err,nil)
  end
  local response_read,response,response_error = protected_call(
    tools.read_http_headers,
    function(bytes)
      return self.sock_receive(self,bytes)
    end,
    MAX_HANDSHAKE_BYTES,
    MAX_HANDSHAKE_LINES
  )
  if not response_read then
    return close_with_error(self,response,nil)
  elseif not response then
    return close_with_error(self,response_error,nil)
  end
  if not string.match(response,'^HTTP/1%.1%s+101%s') then
    return close_with_error(self,'WebSocket handshake did not return HTTP 101',nil)
  end
  local parsed_headers,headers = protected_call(handshake.http_headers,response)
  if not parsed_headers or type(headers) ~= 'table' then
    return close_with_error(
      self,parsed_headers and 'invalid WebSocket handshake response' or headers,nil
    )
  end
  local accept_computed,expected_accept =
    protected_call(handshake.sec_websocket_accept,key)
  if not accept_computed or type(expected_accept) ~= 'string' then
    return close_with_error(self,expected_accept,headers)
  end
  if not header_has_token(headers['upgrade'],'websocket')
    or not header_has_token(headers['connection'],'upgrade')
  then
    return close_with_error(self,'WebSocket handshake is missing Upgrade headers',headers)
  end
  if headers['sec-websocket-accept'] ~= expected_accept then
    local msg = 'Websocket Handshake failed: Invalid Sec-Websocket-Accept (expected %s got %s)'
    return close_with_error(
      self,msg:format(expected_accept,headers['sec-websocket-accept'] or 'nil'),headers
    )
  end
  local selected_protocol = headers['sec-websocket-protocol']
  if selected_protocol ~= nil and not offered_protocols[selected_protocol] then
    return close_with_error(self,'WebSocket server selected an unoffered subprotocol',headers)
  end
  if headers['sec-websocket-extensions'] ~= nil then
    return close_with_error(self,'WebSocket server selected an unoffered extension',headers)
  end
  self.state = 'OPEN'
  return true,selected_protocol,headers
end

local extend = function(obj)
  assert(obj.sock_send)
  assert(obj.sock_receive)
  assert(obj.sock_close)

  assert(obj.is_closing == nil)
  assert(obj.receive    == nil)
  assert(obj.send       == nil)
  assert(obj.close      == nil)
  assert(obj.connect    == nil)

  if not obj.is_server then
    assert(obj.sock_connect)
  end

  if not obj.state then
    obj.state = 'CLOSED'
  end
  obj.is_closing = false

  obj.receive = receive
  obj.send = send
  obj.close = close
  obj.connect = connect

  return obj
end

return {
  extend = extend
}
