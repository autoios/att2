local bit = require'websocket.bit'
local mime = require'mime'
local rol = bit.rol
local bxor = bit.bxor
local bor = bit.bor
local band = bit.band
local bnot = bit.bnot
local lshift = bit.lshift
local rshift = bit.rshift
local sunpack = string.unpack
local srep = string.rep
local schar = string.char
local tinsert = table.insert
local tconcat = table.concat
local protected_call = pcall
local io_open = io.open

local read_n_bytes = function(str, pos, n)
  pos = pos or 1
  return pos+n, string.byte(str, pos, pos + n - 1)
end

local read_int8 = function(str, pos)
  return read_n_bytes(str, pos, 1)
end

local read_int16 = function(str, pos)
  local new_pos,a,b = read_n_bytes(str, pos, 2)
  return new_pos, lshift(a, 8) + b
end

local read_int32 = function(str, pos)
  local new_pos,a,b,c,d = read_n_bytes(str, pos, 4)
  return new_pos,
  lshift(a, 24) +
  lshift(b, 16) +
  lshift(c, 8 ) +
  d
end

local pack_bytes = string.char

local write_int8 = pack_bytes

local write_int16 = function(v)
  return pack_bytes(rshift(v, 8), band(v, 0xFF))
end

local write_int32 = function(v)
  return pack_bytes(
    band(rshift(v, 24), 0xFF),
    band(rshift(v, 16), 0xFF),
    band(rshift(v,  8), 0xFF),
    band(v, 0xFF)
  )
end

-- Both Sec-WebSocket-Key and client-to-server masking require unpredictable
-- bytes.  iOS exposes the kernel CSPRNG at /dev/urandom; never fall back to
-- a weak PRNG or time-derived state when it is unavailable or short-reads.
-- Keep one read-only descriptor per Lua state so masking a busy connection
-- does not add open/close system calls to every frame.
local random_stream
local discard_random_stream = function()
  local stream = random_stream
  random_stream = nil
  if stream then protected_call(stream.close,stream) end
end
local secure_random_bytes = function(count)
  if type(count) ~= 'number' or count ~= math.floor(count) or count < 1 then
    error('secure random byte count must be a positive integer',2)
  end
  if not random_stream then
    local opened,stream,open_error = protected_call(io_open,'/dev/urandom','rb')
    if not opened or not stream then
      error('cryptographically secure random source unavailable: '
        ..tostring(opened and open_error or stream),2)
    end
    random_stream = stream
  end
  local read_called,data,read_error =
    protected_call(random_stream.read,random_stream,count)
  if not read_called or type(data) ~= 'string' or #data ~= count then
    discard_random_stream()
    error('cryptographically secure random source failed: '
      ..tostring(read_called and read_error or data),2)
  end
  return data
end

-- SHA1 hashing from luacrypto, if available
local sha1_crypto
local done,crypto = pcall(require,'crypto')
if done then
  sha1_crypto = function(msg)
    return crypto.digest('sha1',msg,true)
  end
end

-- from wiki article, not particularly clever impl
local sha1_wiki = function(msg)
  local h0 = 0x67452301
  local h1 = 0xEFCDAB89
  local h2 = 0x98BADCFE
  local h3 = 0x10325476
  local h4 = 0xC3D2E1F0

  local bits = #msg * 8
  -- append b10000000
  msg = msg..schar(0x80)

  -- 64 bit length will be appended
  local bytes = #msg + 8

  -- 512 bit append stuff
  local fill_bytes = 64 - (bytes % 64)
  if fill_bytes ~= 64 then
    msg = msg..srep(schar(0),fill_bytes)
  end

  -- append 64 big endian length
  local high = math.floor(bits/2^32)
  local low = bits - high*2^32
  msg = msg..write_int32(high)..write_int32(low)

  assert(#msg % 64 == 0,#msg % 64)

  for j=1,#msg,64 do
    local chunk = msg:sub(j,j+63)
    assert(#chunk==64,#chunk)
    local words = {}
    local next = 1
    local word
    repeat
      next,word = read_int32(chunk, next)
      tinsert(words, word)
    until next > 64
    assert(#words==16)
    for i=17,80 do
      words[i] = bxor(words[i-3],words[i-8],words[i-14],words[i-16])
      words[i] = rol(words[i],1)
    end
    local a = h0
    local b = h1
    local c = h2
    local d = h3
    local e = h4

    for i=1,80 do
      local k,f
      if i > 0 and i < 21 then
        f = bor(band(b,c),band(bnot(b),d))
        k = 0x5A827999
      elseif i > 20 and i < 41 then
        f = bxor(b,c,d)
        k = 0x6ED9EBA1
      elseif i > 40 and i < 61 then
        f = bor(band(b,c),band(b,d),band(c,d))
        k = 0x8F1BBCDC
      elseif i > 60 and i < 81 then
        f = bxor(b,c,d)
        k = 0xCA62C1D6
      end

      local temp = rol(a,5) + f + e + k + words[i]
      e = d
      d = c
      c = rol(b,30)
      b = a
      a = temp
    end

    h0 = h0 + a
    h1 = h1 + b
    h2 = h2 + c
    h3 = h3 + d
    h4 = h4 + e

  end

  -- necessary on sizeof(int) == 32 machines
  h0 = band(h0,0xffffffff)
  h1 = band(h1,0xffffffff)
  h2 = band(h2,0xffffffff)
  h3 = band(h3,0xffffffff)
  h4 = band(h4,0xffffffff)

  return write_int32(h0)..write_int32(h1)..write_int32(h2)..write_int32(h3)..write_int32(h4)
end

local base64_encode = function(data)
  return (mime.b64(data))
end

local base64_decode = function(data)
  return (mime.unb64(data))
end

local DEFAULT_PORTS = {ws = 80, wss = 443}

local parse_url = function(url)
  if type(url) ~= 'string' then error('WebSocket URL must be a string',2) end
  if url:find('[\r\n]') then
    error('WebSocket URL protocol, host, and URI must not contain CR/LF',2)
  end
  if url:find('[%s%c]') then
    error('WebSocket URL host and URI must not contain whitespace or control characters',2)
  end
  local protocol,remainder = url:match('^([%a][%w+%.%-]*)://(.*)$')
  if not protocol then error('Invalid URL:'..url) end
  protocol = protocol:lower()
  if remainder:find('#',1,true) then
    error('WebSocket URL fragments are not permitted',2)
  end
  local address,uri = remainder:match('^([^/%?]*)(.*)$')
  if not address or address == '' then error('WebSocket URL host is empty',2) end
  if address:find('@',1,true) then
    error('WebSocket URL userinfo is not permitted',2)
  end
  if address:find('[%s%c]') then
    error('WebSocket URL authority must not contain whitespace or control characters',2)
  end

  local host
  local host_header
  local port_text
  if address:sub(1,1) == '[' then
    local closing = address:find(']',2,true)
    if not closing then error('WebSocket URL has an unterminated IPv6 literal',2) end
    host = address:sub(2,closing - 1)
    if host == '' or not host:find(':',1,true) then
      error('WebSocket URL has an invalid bracketed IPv6 literal',2)
    end
    host_header = '['..host..']'
    local suffix = address:sub(closing + 1)
    if suffix ~= '' then
      port_text = suffix:match('^:(%d+)$')
      if not port_text then
        error('WebSocket URL has an invalid or empty port',2)
      end
    end
  else
    if address:find('[%[%]]') then
      error('WebSocket URL has malformed host brackets',2)
    end
    local first_colon = address:find(':',1,true)
    if first_colon then
      if address:find(':',first_colon + 1,true) then
        error('WebSocket URL bare IPv6 literals are ambiguous; use brackets',2)
      end
      host,port_text = address:match('^([^:]+):(%d+)$')
      if not host or not port_text then
        error('WebSocket URL has an invalid or empty port',2)
      end
    else
      host = address
    end
    host_header = host
  end
  if not host or host == '' then error('WebSocket URL host is empty',2) end

  local port
  if port_text then
    port = tonumber(port_text)
    if not port or port < 1 or port > 65535 then
      error('WebSocket URL port must be between 1 and 65535',2)
    end
  else
    port = DEFAULT_PORTS[protocol]
  end
  if not uri or uri == '' then
    uri = '/'
  elseif uri:sub(1,1) == '?' then
    uri = '/'..uri
  end
  return protocol,host,port,uri,host_header
end

local generate_key = function()
  local key = secure_random_bytes(16)
  assert(#key==16,#key)
  return base64_encode(key)
end

-- LuaSocket's "*l" receive pattern has no line-length limit, so checking the
-- aggregate size after it returns is too late.  Read one byte at a time until
-- the CRLF header terminator, enforcing both bounds before requesting another
-- byte and rejecting ambiguous bare-LF/isolated-CR input.
local read_http_headers = function(receive,max_bytes,max_lines)
  if type(receive) ~= 'function' then
    error('bounded HTTP header reader requires a receive function',2)
  end
  max_bytes = max_bytes or 64 * 1024
  max_lines = max_lines or 200
  if type(max_bytes) ~= 'number' or max_bytes ~= math.floor(max_bytes)
    or max_bytes < 1
    or type(max_lines) ~= 'number' or max_lines ~= math.floor(max_lines)
    or max_lines < 1
  then
    error('bounded HTTP header limits must be positive integers',2)
  end

  local lines = {}
  local current_line = {}
  local bytes_read = 0
  local lines_read = 0
  local pending_cr = false
  while true do
    if bytes_read >= max_bytes then
      return nil,'WebSocket handshake headers exceed configured byte limit'
    end
    local called,chunk,receive_error,partial = protected_call(receive,1)
    if not called then
      return nil,tostring(chunk)
    end
    if chunk == nil and type(partial) == 'string' and #partial > 0 then
      chunk = partial
    end
    if type(chunk) ~= 'string' or #chunk ~= 1 then
      return nil,tostring(receive_error or 'closed during WebSocket handshake')
    end
    bytes_read = bytes_read + 1
    if pending_cr and chunk ~= '\n' then
      return nil,'WebSocket handshake header line contains an isolated CR'
    end
    if chunk == '\n' then
      if not pending_cr then
        return nil,'WebSocket handshake header line contains a bare LF'
      end
      pending_cr = false
      lines_read = lines_read + 1
      if lines_read > max_lines then
        return nil,'WebSocket handshake headers exceed configured line limit'
      end
      local line = tconcat(current_line)
      current_line = {}
      if line == '' then
        return tconcat(lines,'\r\n')..'\r\n\r\n',nil,bytes_read,lines_read
      end
      tinsert(lines,line)
    elseif chunk == '\r' then
      pending_cr = true
    else
      local byte = string.byte(chunk)
      if (byte < 32 and byte ~= 9) or byte == 127 then
        return nil,'WebSocket handshake header line contains a control character'
      end
      tinsert(current_line,chunk)
    end
  end
end

return {
  sha1 = sha1_crypto or sha1_wiki,
  base64 = {
    encode = base64_encode,
    decode = base64_decode,
  },
  parse_url = parse_url,
  generate_key = generate_key,
  random_bytes = secure_random_bytes,
  read_http_headers = read_http_headers,
  read_int8 = read_int8,
  read_int16 = read_int16,
  read_int32 = read_int32,
  write_int8 = write_int8,
  write_int16 = write_int16,
  write_int32 = write_int32,
}
