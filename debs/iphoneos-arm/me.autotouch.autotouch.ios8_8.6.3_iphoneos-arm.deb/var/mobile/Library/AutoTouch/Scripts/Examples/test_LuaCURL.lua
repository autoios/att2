local curl = require("cURL")

-- Initialize a table to collect responses
local responses = {}

-- Function to add responses to the collection
local function addResponse(response)
    table.insert(responses, response)
end

-- Function to perform a GET request
function performGETRequest(url)
    local c =
        curl.easy {
        url = url,
        writefunction = function(response)
            addResponse("GET Response: " .. response)
            return true -- to keep the connection open
        end
    }

    -- Perform the GET request
    c:perform()

    -- Cleanup
    c:close()
end

-- Function to perform a POST request
function performPOSTRequest(url, data)
    local c =
        curl.easy {
        url = url,
        post = true,
        postfields = data,
        httpheader = {
            "Content-Type: application/x-www-form-urlencoded"
        },
        writefunction = function(response)
            addResponse("POST Response: " .. response)
            return true -- to keep the connection open
        end
    }

    -- Perform the POST request
    c:perform()

    -- Cleanup
    c:close()
end

-- Function to display all responses in an alert
function showAlertWithResponses()
    local allResponses = table.concat(responses, "\n")
    alert(allResponses) -- Assuming 'alert' is a predefined function to show an alert box
end

-- Function to test LuaCURL with both GET and POST requests
function testLuaCURL()
    local testGETUrl = "http://httpbin.org/get"
    local testPOSTUrl = "http://httpbin.org/post"
    local postData = "key1=value1&key2=value2"

    -- Perform GET request
    performGETRequest(testGETUrl)

    -- Perform POST request
    performPOSTRequest(testPOSTUrl, postData)

    -- Display all responses in an alert
    showAlertWithResponses()
end

-- Call the test function
testLuaCURL()
