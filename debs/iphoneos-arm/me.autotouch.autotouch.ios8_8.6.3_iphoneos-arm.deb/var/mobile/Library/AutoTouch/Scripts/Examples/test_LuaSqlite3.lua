-- Import the LuaSqlite3 module
local sqlite3 = require("lsqlite3")

-- Function to test database connection
local function test_open_close_database()
    local db = sqlite3.open(":memory:") -- Open a database in RAM
    assert(db, "Failed to open the database.")
    print("Database opened successfully.")

    db:close()
    print("Database closed successfully.")
end

-- Function to test executing a simple SQL command
local function test_execute_sql()
    local db = sqlite3.open(":memory:")
    local sql =
        [[
        CREATE TABLE test (id INTEGER PRIMARY KEY, name TEXT);
        INSERT INTO test (name) VALUES ('Lua');
        SELECT * FROM test;
    ]]

    local stmt = db:prepare(sql)
    assert(stmt, "Failed to prepare SQL statement.")

    local step = stmt:step()
    assert(step == sqlite3.DONE or step == sqlite3.ROW, "Failed to execute SQL statement.")
    print("SQL executed successfully.")

    stmt:finalize()
    db:close()
end

-- Function to test transactions
local function test_transactions()
    local db = sqlite3.open(":memory:")
    db:exec("CREATE TABLE test (id INTEGER PRIMARY KEY, name TEXT)")

    db:exec("BEGIN TRANSACTION")
    db:exec("INSERT INTO test (name) VALUES ('Transaction')")
    db:exec("ROLLBACK")

    local count = 0
    for row in db:nrows("SELECT * FROM test") do
        count = count + 1
    end
    assert(count == 0, "Transaction rollback failed.")
    print("Transaction test passed.")

    db:close()
end

-- Main function to run all tests
local function run_tests()
    test_open_close_database()
    test_execute_sql()
    test_transactions()
    alert("All tests completed successfully.")
end

run_tests()
