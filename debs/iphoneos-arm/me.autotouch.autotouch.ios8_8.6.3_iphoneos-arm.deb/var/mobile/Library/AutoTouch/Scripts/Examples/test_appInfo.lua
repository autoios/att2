-- Define the app identifier you want to test
local appIdentifier = "com.apple.Home" -- Replace with the actual app identifier

-- Call the appInfo function and get the app information
local info = appInfo(appIdentifier)

if info then
    alert(table.toString(info, true))
else
    alert("No information found for the app: " .. appIdentifier)
end
