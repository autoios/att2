local function is_array(value)
    if type(value) ~= "table" then
        return false
    end

    local count = 0
    for key, _ in pairs(value) do
        if type(key) ~= "number" then
            return false
        end
        count = count + 1
    end

    for i = 1, count do
        if value[i] == nil then
            return false
        end
    end

    return true
end

local function serialize(value, indent, visited)
    local value_type = type(value)
    if value_type == "nil" then
        return "nil"
    end
    if value_type == "number" or value_type == "boolean" then
        return tostring(value)
    end
    if value_type == "string" then
        return string.format("%q", value)
    end
    if value_type ~= "table" then
        return string.format("%q", tostring(value))
    end

    visited = visited or {}
    if visited[value] then
        return '"<cycle>"'
    end
    visited[value] = true

    indent = indent or ""
    local next_indent = indent .. "  "
    local parts = {}

    if is_array(value) then
        for i = 1, #value do
            parts[#parts + 1] = next_indent .. serialize(value[i], next_indent, visited)
        end
    else
        local keys = {}
        for key, _ in pairs(value) do
            keys[#keys + 1] = key
        end
        table.sort(keys, function(a, b)
            return tostring(a) < tostring(b)
        end)

        for _, key in ipairs(keys) do
            local rendered_key = tostring(key)
            local rendered_value = serialize(value[key], next_indent, visited)
            parts[#parts + 1] = string.format("%s%s = %s", next_indent, rendered_key, rendered_value)
        end
    end

    visited[value] = nil

    if #parts == 0 then
        return "{}"
    end

    return "{\n" .. table.concat(parts, ",\n") .. "\n" .. indent .. "}"
end

local function log_capture_debug_info()
    log("========== captureDebugInfo example START ==========")

    local info = captureDebugInfo()
    if type(info) ~= "table" then
        log("captureDebugInfo returned a non-table value: " .. tostring(info))
        alert("captureDebugInfo failed. Check log.txt.")
        return
    end

    if info.error then
        log("captureDebugInfo error: " .. tostring(info.error))
        log("Full result: " .. serialize(info))
        alert("captureDebugInfo returned an error. Check log.txt.")
        return
    end

    if info.schemaVersion ~= 2 then
        log("Unsupported captureDebugInfo schema: " .. tostring(info.schemaVersion))
        log("Safe summary: " .. serialize({error = info.error, schemaVersion = info.schemaVersion}))
        alert("Unsupported captureDebugInfo schema. Check log.txt.")
        return
    end
    if type(info.legacyProbeApplicable) ~= "boolean" then
        log("Invalid legacyProbeApplicable: " .. tostring(info.legacyProbeApplicable))
        alert("Invalid captureDebugInfo capability. Check log.txt.")
        return
    end

    log(string.format("schemaVersion=2 legacyProbeApplicable=%s",
        tostring(info.legacyProbeApplicable)))
    if info.legacyProbeApplicable == true then
        log(string.format(
            "legacy active type=%s raw=%sx%s bpr=%s fmt=%s",
            tostring(info.activeTypeName),
            tostring(info.activeWidth),
            tostring(info.activeHeight),
            tostring(info.activeBytesPerRow),
            tostring(info.activePixelFormat)
        ))
        log(string.format(
            "legacy probe source=%s detected=%s raw=%sx%s bpr=%s fmt=%s ref=%sx%s",
            tostring(info.probeSource),
            tostring(info.probeDetectedTypeName),
            tostring(info.probeRawWidth),
            tostring(info.probeRawHeight),
            tostring(info.probeRawBytesPerRow),
            tostring(info.probeRawPixelFormat),
            tostring(info.probeReferenceWidth),
            tostring(info.probeReferenceHeight)
        ))
        local scores = info.probeScores or {}
        log(string.format(
            "legacy probe scores: BADC=%s DABC=%s ADCB=%s",
            tostring(scores.BADC), tostring(scores.DABC), tostring(scores.ADCB)
        ))
    else
        log(string.format(
            "canonical backend=%s state=%s architecture=%s provider=%s lastError=%s",
            tostring(info.activeBackend),
            tostring(info.brokerState),
            tostring(info.architectureVersion),
            tostring(info.displayProviderError),
            tostring(info.lastError)
        ))
        log(string.format(
            "canonical format=%s colorSpace=%s alpha=%s short=%s long=%s orientation=%s",
            tostring(info.canonicalPixelFormat),
            tostring(info.canonicalColorSpace),
            tostring(info.canonicalAlpha),
            tostring(info.shortEdgePixels),
            tostring(info.longEdgePixels),
            tostring(info.interfaceOrientationRaw)
        ))
    end

    log("Full captureDebugInfo result:")
    log(serialize(info))
    log("========== captureDebugInfo example END ==========")

    alert("captureDebugInfo written to /var/mobile/Library/AutoTouch/Library/log.txt")
end

log_capture_debug_info()
