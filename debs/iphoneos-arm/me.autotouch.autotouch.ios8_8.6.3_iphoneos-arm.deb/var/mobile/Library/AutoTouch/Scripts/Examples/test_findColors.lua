-- Function to calculate the left-top most pixel
local function findLeftTopMostPixel(pixels)
    local leftTopMostPixel = pixels[1]
    for _, pixel in ipairs(pixels) do
        if pixel[2] < leftTopMostPixel[2] or (pixel[2] == leftTopMostPixel[2] and pixel[1] < leftTopMostPixel[1]) then
            leftTopMostPixel = pixel
        end
    end
    return leftTopMostPixel
end

-- Function to calculate region properties
local function calculateRegionProperties(pixels)
    local minX, minY = pixels[1][1], pixels[1][2]
    local maxX, maxY = pixels[1][1], pixels[1][2]

    for _, pixel in ipairs(pixels) do
        local x, y = pixel[1], pixel[2]
        if x < minX then
            minX = x
        end
        if x > maxX then
            maxX = x
        end
        if y < minY then
            minY = y
        end
        if y > maxY then
            maxY = y
        end
    end

    local width = maxX - minX
    local height = maxY - minY
    local centerX = minX + width / 2
    local centerY = minY + height / 2

    return {x = minX, y = minY, width = width, height = height, centerX = centerX, centerY = centerY}
end

-- Function to print region properties
local function printRegionProperties(region)
    log(
        string.format(
            "Region - X: %.2f, Y: %.2f, Width: %.2f, Height: %.2f, CenterX: %.2f, CenterY: %.2f",
            region.x,
            region.y,
            region.width,
            region.height,
            region.centerX,
            region.centerY
        )
    )
end

-- Function to generate random pixels within a given region
local function generateRandomPixels(region, numPixels)
    local pixels = {}
    for i = 1, numPixels do
        local x = math.random(region.x, region.x + region.width)
        local y = math.random(region.y, region.y + region.height)
        table.insert(pixels, {x, y})
    end
    return pixels
end

-- Function to test findColors with given parameters
local function runTest(testId, rightToLeft, bottomToTop, totalTests)
    local successCount = 0

    for i = 1, totalTests do
        -- Generate a random region
        local regionX = math.random(0, 500)
        local regionY = math.random(0, 500)
        local regionWidth = math.random(50, 200)
        local regionHeight = math.random(50, 200)
        local region = {x = regionX, y = regionY, width = regionWidth, height = regionHeight}

        -- Generate a random number of pixels
        local numPixels = math.random(3, 10)
        local pixels = generateRandomPixels(region, numPixels)

        -- Step 1: Calculate region properties
        local regionProps = calculateRegionProperties(pixels)
        printRegionProperties(regionProps)

        -- Find the left-top most pixel
        local leftTopMostPixel = findLeftTopMostPixel(pixels)

        -- Step 2: Get colors of those pixels
        local colorsResult = getColors(pixels)
        local colors = {}
        for j, v in pairs(colorsResult) do
            table.insert(colors, {v, pixels[j][1] - leftTopMostPixel[1], pixels[j][2] - leftTopMostPixel[2]})
        end

        log("Colors of the specific pixels: " .. table.tostring(colors))

        -- Step 3: Find colors with the colors and relative positions
        local foundRegions = findColors(colors, 0, nil, false, rightToLeft, bottomToTop)

        -- Step 4: Check if all the regions are found correctly
        local allFound = false
        if foundRegions == nil then
            alert("Error: foundRegions is nil")
            return 0  -- Return from runTest function
        elseif #foundRegions > 0 then
            for _, foundRegion in pairs(foundRegions) do
                if foundRegion[1] == leftTopMostPixel[1] and foundRegion[2] == leftTopMostPixel[2] then
                    allFound = true
                    break
                end
            end
        end

        if allFound then
            successCount = successCount + 1
            log(string.format("Test %d.%d: All regions found correctly.", testId, i))
        else
            log(string.format("Test %d.%d: Not all regions found correctly.", testId, i))
        end
    end

    return successCount
end

-- Run the tests for all cases
local function testFindColors()
    local startTime = os.time()  -- Add time tracking at start
    local totalTests = 50
    local results = {}

    -- Test case 1: top to bottom, left to right
    results[1] = runTest(1, false, false, totalTests)
    -- Test case 2: top to bottom, right to left
    results[2] = runTest(2, true, false, totalTests)
    -- Test case 3: bottom to top, left to right
    results[3] = runTest(3, false, true, totalTests)
    -- Test case 4: bottom to top, right to left
    results[4] = runTest(4, true, true, totalTests)

    local endTime = os.time()  -- Add time tracking at end
    local totalTime = endTime - startTime  -- Calculate total time

    -- Alert the success percentages for each case
    local message = "Test Results:\n"
    local descriptions = {
        "Find from top-left to bottom-right",
        "Find from top-right to bottom-left",
        "Find from bottom-left to top-right",
        "Find from bottom-right to top-left"
    }

    for i = 1, 4 do
        message = message .. string.format("%s: %d out of %d are success\n", descriptions[i], results[i], totalTests)
    end

    -- Add execution time to the message
    message = message .. string.format("\nTotal execution time: %d seconds", totalTime)

    alert(message)
end

-- Run the tests
testFindColors()
