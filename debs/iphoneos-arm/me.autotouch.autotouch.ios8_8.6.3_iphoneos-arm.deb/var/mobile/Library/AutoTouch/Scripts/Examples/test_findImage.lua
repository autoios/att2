-- Function to generate a random region within screen limits
function randomRegion()
    local screen_metrics = requireScreenMetrics("Examples.test_findImage.randomRegion")
    local screenWidth, screenHeight = screen_metrics.pixelWidth, screen_metrics.pixelHeight
    local w = math.random(100, math.floor(screenWidth * 0.5)) -- Smaller width to avoid edge cases
    local h = math.random(100, math.floor(screenHeight * 0.5)) -- Smaller height for the same reason
    local x = math.random(0, screenWidth - w)
    local y = math.random(0, screenHeight - h)
    return {x, y, w, h}
end

-- Function to test findImage with screenshot
function testFindImage(iterations, tolerance)
    local matchSuccess = 0
    local startTime = os.clock() -- More precise timing

    for i = 1, iterations do
        local region = randomRegion()

        local imagePath = string.format("images/test_screenshot_%d.png", i)

        -- Calculate the center of the region
        local centerX = (region[1] + region[3] / 2)
        local centerY = (region[2] + region[4] / 2)

        log(
            string.format(
                "Test region x:%f, y:%f, w:%f, h:%f, centerX: %f, centerY: %f",
                region[1],
                region[2],
                region[3],
                region[4],
                centerX,
                centerY
            )
        )

        -- Take a screenshot of the random region
        screenshot(imagePath, region)

        -- Try to find the screenshot in the entire screen with a lower threshold
        local result = findImage(imagePath, 1, 0.9, nil, true, 1) -- Lowered accuracy to 0.9, use method `1` (Local matching template).
        if next(result) then -- Check if any result was found
            local found = result[1]
            local foundX = found[1]
            local foundY = found[2]
            -- Validate if found region is within an acceptable margin of the expected center
            if math.abs(foundX - centerX) <= tolerance and math.abs(foundY - centerY) <= tolerance then
                matchSuccess = matchSuccess + 1
            end
            log(
                string.format(
                    "Test %d: Found image center at x:%f, y:%f. Expected center x:%f, y:%f",
                    i,
                    foundX,
                    foundY,
                    centerX,
                    centerY
                )
            )
        else
            log(string.format("Test %d: No match found.", i))
        end

        -- Optional: delete the image after test to save storage
        os.remove(imagePath)
    end

    local endTime = os.clock()
    local totalTime = endTime - startTime

    -- Updated alert with precise timing
    alert(string.format("Success rate: %d/%d\nTotal time: %.2f seconds", matchSuccess, iterations, totalTime))
end

-- Run the test for 20 iterations, and tolerance = 10
testFindImage(20, 10)
