function getRandomCoordinate(maxValue)
    return math.random(1, maxValue)
end

local screen_metrics = requireScreenMetrics("Examples.test_getAndFindColor")

local w, h = screen_metrics.pixelWidth, screen_metrics.pixelHeight
-- log(string.format(">>>>>>> screen resolution: %d, %d", w, h))

-- Set the range for random coordinates, adjust as needed for your screen resolution or test range
-- local maxX, maxY = 768, 1024
local maxX, maxY = w, h
local testCount = 100 -- Number of tests to perform
local allMatched = true -- Flag to track if all tests match
local matchCount = 0 -- Counter for successful matches
local coordinates = {}

-- Generate all test coordinates first
for i = 1, testCount do
    table.insert(coordinates, {getRandomCoordinate(maxX), getRandomCoordinate(maxY)})
end

-- Retrieve colors for all generated coordinates at once
local results = getColors(coordinates)
if not results or #results == 0 then
    alert("Failed: No colors retrieved from any of the test coordinates.")
    return -- Exit if no results were retrieved
end

-- Process each result to find the match
for i = 1, testCount do
    local x, y = coordinates[i][1], coordinates[i][2]
    local color = results[i]
    if color then -- Only proceed if there is a color to process
        local searchResults = findColor(color, 0, nil)
        local found = false

        for _, v in pairs(searchResults) do
            if v[1] == x and v[2] == y then
                found = true
                break -- Found a match, no need to continue checking
            end
        end

        if found then
            matchCount = matchCount + 1 -- Increment match counter
        else
            allMatched = false -- Set allMatched to false if any match fails
        end
    else
        allMatched = false -- Set allMatched to false if no color is found, mimicking a continue
    end
end

-- Final alert based on the overall result
if allMatched then
    alert(string.format("Success: All %d pixels get and find operations matched correctly.", testCount))
else
    alert(
        string.format(
            "Failed: Only %d out of %d pixels get and find operations matched correctly.",
            matchCount,
            testCount
        )
    )
end
