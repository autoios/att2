-- Load the json library
local json = require "json"

-- Helper function to compare tables for equality, ignoring key order
local function decode_and_compare(json_string, expected_table)
    local decoded = json.decode(json_string)
    if type(decoded) ~= "table" then
        return false
    end
    for key, value in pairs(expected_table) do
        if decoded[key] ~= value then
            return false
        end
    end
    for key, value in pairs(decoded) do
        if expected_table[key] ~= value then
            return false
        end
    end
    return true
end

-- Test encoding
assert(json.encode({true, false}) == "[true,false]", "Failed to encode booleans")
assert(json.encode({1, 2, 3}) == "[1,2,3]", "Failed to encode array of numbers")
local encoded_object = json.encode({name = "John", age = 30})
assert(decode_and_compare(encoded_object, {name = "John", age = 30}), "Failed to encode object")

-- Test decoding
assert(
    json.decode("[true,false,null]")[1] == true and json.decode("[true,false,null]")[2] == false and
        json.decode("[true,false,null]")[3] == nil,
    "Failed to decode booleans and null"
)
assert(
    json.decode("[1,2,3]")[1] == 1 and json.decode("[1,2,3]")[2] == 2 and json.decode("[1,2,3]")[3] == 3,
    "Failed to decode array of numbers"
)
assert(decode_and_compare('{"name":"John","age":30}', {name = "John", age = 30}), "Failed to decode object")

-- Edge Cases
assert(json.encode({}) == "[]", "Failed to encode empty table as array")
assert(json.encode(nil) == "null", "Failed to encode nil as null")
assert(decode_and_compare("{}", {}), "Failed to decode empty object")

-- Special Cases for nil within tables
local complex_table = {some_key = "some_value", nil_value = json.null}
local encoded_complex_table = json.encode(complex_table)
assert(
    decode_and_compare(encoded_complex_table, {some_key = "some_value", nil_value = json.null}),
    "Failed to encode complex table with explicit null"
)

alert("All tests of json passed!")
