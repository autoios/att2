local lfs = require("lfs")

-- Helper function to display results as print statements and collect successes and failures
local function testResult(success, msg)
    local symbol = success and "✅" or "❌"
    print(symbol .. " " .. msg)
    return msg, success
end

-- Function to get the absolute path of a directory
function getAbsolutePath(directory)
    local originalDir = lfs.currentdir() -- Store the current directory
    local success, err = lfs.chdir(directory) -- Change to the target directory
    if not success then
        return nil, "Error changing directory: " .. err -- Return nil and an error if the directory change fails
    end

    local absolutePath = lfs.currentdir() -- Get the absolute path of the new current directory
    lfs.chdir(originalDir) -- Revert back to the original directory

    return absolutePath
end

-- Root directory for testing
local testDir = rootDir() .. "/TestLFS"

-- Create a directory for tests
local function setupDirectory()
    local success, err = lfs.mkdir(testDir)
    return success or lfs.attributes(testDir, "mode") == "directory", "Create test directory"
end

-- Function to test changing and getting the current directory
function testChangeDirectory()
    local initialDir = lfs.currentdir()
    local initialAbsPath = getAbsolutePath(initialDir)
    if not initialAbsPath then
        return false, "Failed to get absolute path of initial directory"
    end

    local testDirAbsPath = getAbsolutePath(testDir)
    if not testDirAbsPath then
        return false, "Failed to get absolute path of test directory"
    end

    local success, err = lfs.chdir(testDir)
    if not success then
        return false, "Change current directory failed: " .. err
    end

    local newDir = lfs.currentdir()
    local newDirAbsPath = getAbsolutePath(newDir)
    if not newDirAbsPath then
        lfs.chdir(initialDir) -- Ensure we revert back even if path resolution fails
        return false, "Failed to get absolute path after changing directory"
    end

    lfs.chdir(initialDir) -- Revert back to the original directory

    if newDirAbsPath == testDirAbsPath then
        return true, "Successfully changed current directory"
    else
        return false, "Directory was changed back, but the test directory did not match the expected directory"
    end
end

-- Test removing a directory
local function testRemoveDirectory()
    -- Ensure directory is empty before removing
    for file in lfs.dir(testDir) do
        if file ~= "." and file ~= ".." then
            os.remove(testDir .. "/" .. file)
        end
    end
    local success, err = lfs.rmdir(testDir)
    return success, "Remove directory: " .. (err or "success")
end

-- Test creating, writing, and reading a file
local function testFileOperations()
    local filePath = testDir .. "/testfile.txt"
    local file, err = io.open(filePath, "w")
    if not file then
        return false, "Create file failed: " .. err
    end
    file:write("Hello, world!")
    file:close()

    file, err = io.open(filePath, "r")
    if not file then
        return false, "Read file failed: " .. err
    end
    local content = file:read("*all")
    file:close()
    return content == "Hello, world!", "File operations (create, write, read)"
end

-- Test listing directory contents
local function testListDirectory()
    local exists = false
    for file in lfs.dir(testDir) do
        if file == "testfile.txt" then
            exists = true
            break
        end
    end
    return exists, "List directory contents"
end

-- Test file attributes
local function testFileAttributes()
    local attr, err = lfs.attributes(testDir .. "/testfile.txt")
    if attr and attr.mode == "file" then
        return true, "Check file attributes"
    else
        return false, "Check file attributes: " .. (err or "unknown error")
    end
end

-- Test removing a file
local function testRemoveFile()
    local filePath = testDir .. "/testfile.txt"
    local exists = lfs.attributes(filePath)
    if not exists then
        return true, "File already removed or does not exist"
    end
    os.remove(filePath)
    local attr = lfs.attributes(filePath)
    return not attr, "Remove file"
end

-- Test updating file access and modification times
local function testTouchFile()
    -- Generate a random file name to avoid conflicts
    local filePath = testDir .. "/testfile_" .. math.random(100000, 999999) .. ".txt"

    -- Create a new file
    local file, err = io.open(filePath, "w")
    if not file then
        return false, "Failed to create file: " .. err
    end
    file:write("This is a temporary file created for testing lfs.touch.")
    file:close()

    -- Update the file times
    local success, err = lfs.touch(filePath, os.time(), os.time())
    if not success then
        os.remove(filePath) -- Clean up even in case of failure
        return false, "Update file times error: " .. err
    end

    -- Clean up: Remove the file after testing
    os.remove(filePath)
    return true, "Update file times success"
end

-- Main testing function
local function runTests()
    local tests = {
        setupDirectory,
        testFileOperations,
        testChangeDirectory,
        testListDirectory,
        testFileAttributes,
        testRemoveFile,
        testTouchFile,
        testRemoveDirectory -- This should be the last test as it cleans up the test directory
    }

    local successes = {}
    local failures = {}

    for _, test in ipairs(tests) do
        local success, message = test()
        local resultMessage, isSuccess = testResult(success, message)
        if isSuccess then
            table.insert(successes, "- " .. resultMessage)
        else
            table.insert(failures, "- " .. resultMessage)
        end
    end

    local successesText = #successes > 0 and table.concat(successes, "\n") or "None"
    local failuresText = #failures > 0 and table.concat(failures, "\n") or "None"

    local finalMessage = "Test Results:\n\n✅ Successes:\n" .. successesText .. "\n\n❌ Failures:\n" .. failuresText
    alert(finalMessage)
end

-- Execute the tests
runTests()
