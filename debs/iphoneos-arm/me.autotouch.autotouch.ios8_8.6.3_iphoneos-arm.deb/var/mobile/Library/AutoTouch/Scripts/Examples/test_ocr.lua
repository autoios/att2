-- Example:

-- Use remote AI service which bases on `TesseractOCR` at present.
local options = {
    -- OPTIONAL, default is `OCR_METHOD.IOS_VISION`, `AI_CLOUD` means remote AI service which bases on `TesseractOCR`.
    method = OCR_METHOD.AI_CLOUD,

    -- OPTIONAL, image path (relative or absolute path), default is nil, nil means do ocr on the screen, otherwise do ocr on the provided image.
    -- image = "./image.png",

    -- OPTIONAL, specified the region to recognize text, default is nil which means the whole screen.
    region = {100, 100, 500, 500},

    -- OPTIONAL, you can find the options from https://github.com/tesseract-ocr/tessdata
    lang = 'eng+fra',

    -- OPTIONAL, what characters you want to recognize in the region, such as "0123456789" will find numbers only, default is nil.
    -- whitelist = '1234567890',

    -- OPTIONAL, default is 10 seconds
    timeout = 30,

    -- OPTIONAL, whether you want to produce debug image, default is false
    debug = true,
}

local result = ocr(options)
local s = table.tostring(result)
alert(s)

-- Example:

-- Use iOS built-in `Vision.framework` to do ocr, it usually works better than others, 
-- but might have issue on some devices or with some jailbreak tools.
local options = {
    -- OPTIONAL, default is `OCR_METHOD.IOS_VISION`
    method = OCR_METHOD.IOS_VISION,

    -- OPTIONAL, image path (relative or absolute path), default is nil, nil means do ocr on the screen, otherwise do ocr on the provided image.
    -- image = "./image.png",
    
    -- OPTIONAL, specified the region to recognize text, default is nil which means the whole screen.
    region = {100, 100, 500, 500},
    
    -- OPTIONAL, an array of strings to supplement the recognized languages at the word recognition stage, default is nil.
    -- customWords = {"Playing"},
    
    -- OPTIONAL, the minimum height of the text expected to be recognized, relative to the region/screen height, default is 1/32.
    -- minimumTextHeight = nil,

    -- OPTIONAL, default is 0 which means accurate first, value 1 means speed first
    -- level = 0,

    -- OPTIONAL, an array of languages to detect, in priority order. ISO language codes: http://www.lingoes.net/en/translator/langcode.htm.
    languages = {'en-US', "fr-FR"},

    -- OPTIONAL, whether use language correction during the recognition process, default is false
    correct = true,

    -- OPTIONAL, default is 10 seconds
    timeout = 10,

    -- OPTIONAL, whether you want to produce debug image, default is false
    debug = true,
}

local result = ocr(options)
local s = table.tostring(result)
alert(s)

-- Example

-- Got table(array) result with format:
-- {
--     {
--         "text": "Example",
--         "rectangle": {
--             "bottomRight": {
--                 "x": 300.47,
--                 "y": 177.78
--             },
--             "topRight": {
--                 "x": 300.47,
--                 "y": 237.52
--             },
--             "topLeft": {
--                 "x": 33.51,
--                 "y": 237.42
--             },
--             "bottomLeft": {
--                 "x": 33.51,
--                 "y": 177.68
--             }
--         }
--     }
-- }