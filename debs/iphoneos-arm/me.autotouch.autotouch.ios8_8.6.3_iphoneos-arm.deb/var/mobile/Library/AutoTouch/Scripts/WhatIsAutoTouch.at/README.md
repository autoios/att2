# AutoTouch / Live Demo

A complete workflow in seven short chapters: **see, tap, draw, scroll, pinch, type, read and decide, then save the evidence**. All automation and page logic run in Lua. The offline Safari playground is served by the script itself with LuaSocket and uses HTML and CSS only, with no JavaScript or external requests.

## Run the tour

1. Run `WhatIsAutoTouch.at` in AutoTouch.
2. Choose the full experience or an individual chapter, enter demo text, and optionally enable the slower explanation pace (on by default).
3. Keep the device unlocked and Safari visible. Watch without touching the screen. Native toasts at the top of the screen narrate each step.
4. Tip: AutoTouch › Settings › Touch Indicator shows every simulated finger.
5. Hold Volume Down, or tap **Finish** at the top of the page, to stop. The results page returns to AutoTouch after 25 seconds, and a summary dialog shows how many chapters were verified.

Requirements: Safari, the bundled LuaSocket/lfs/JSON modules, working screen capture and simulated touch, the license required by image matching, and system Vision support for local OCR. Both the basic and inputText editions can complete the tour. If another browser is the default, open the demo link in Safari before retrying.

## Seven live chapters

| Chapter | Actual operations | Completion evidence |
|---|---|---|
| 01 Color and tap | Search a multi-point color pattern, re-sample it, send a touch | A browser receipt from the target |
| 02 Screenshot and image match | Capture a template, match it, tap the matched center | Checked match location and browser receipt |
| 03 Speed and precision | A Lua loop taps 27 cells of a 7×6 grid into a heart, `getColors` checks all 42 cells and re-taps any miss | The browser receives exactly the planned cells |
| 04 Smart scrolling | Screen-relative smooth swipes with a visual check after each one | The target is found and acknowledges the tap |
| 05 Two-finger pinch | Two fingers move apart at the same time; Safari zooms in | `getColors` measures the ruler before and after (at least 1.4×) |
| 06 Text and data handoff | Use keyboard input when available; otherwise prepare text in Lua and automatically tap Submit | Received UTF-8 text exactly matches the original; the report identifies the method |
| 07 Read, decide, act | OCR reads a new random sum each run, Lua computes it and taps the answer by finding its text box | The browser confirms the correct answer |

The drawing grid is located by two corner anchors, so its cells are computed correctly at any display scale. Questions and answers in chapter 7 change on every run, so nothing is hard-coded.

Each chapter has a 25-second wait limit. The scrolling chapter allows up to eight swipes. The session wait limit is 120 seconds without progress, renewed after each chapter and after a recovery dialog.

Toasts are part of the screen image, so every search and OCR region starts below the toast area in portrait, and a new toast never covers the previous one. In landscape the tour runs without narration.

The text chapter adapts automatically. A readable standard injection filter selects the Lua-to-form workflow immediately. Enabled or unknown configurations try keyboard input; if delivery fails or its browser receipt does not arrive, the tour switches to the form workflow without a dialog. A failed form step is recorded as UNAVAILABLE and the tour continues. This does not enable inputText, change injection settings or restart any app. A form result never claims that keyboard input was verified.

## Results

Each run creates a separate `results/<timestamp>-<number>/` directory in this script package:

- `report.html`: a standalone offline report with every chapter's evidence and next steps.
- `report.json`: time, version, tour duration, demo text and actual chapter outcomes, each with a `summary` and measured `evidence` (positions, timings, tap counts, zoom factor, OCR numbers); the text result records `textMode` as `keyboard` or `form`.
- `template.png`: the captured image-matching template.
- `drawing.png`: the drawing after the pixel check.
- `pinch.png`: the zoomed page after the two-finger gesture.
- `ocr.png`: the question and answers that OCR read.

Statuses are VERIFIED, FAILED (the browser received a wrong drawing or answer), MANUAL (activated by hand), SKIPPED, UNAVAILABLE and INCOMPLETE. Only VERIFIED counts as automation.

The tour uses only your demo text. It does not read the clipboard, change the photo library or schedule future scripts. Its temporary server listens only on the device's loopback interface and closes on normal/error exits. Force-stopping playback releases its resources with the Lua state. Remaining Safari tabs can be closed manually. Results are retained for inspection.

## Learn from the source

- `main.lua`: package entry point.
- `toolkit.lua`: copy-ready helpers: `locate` (color pattern + re-sample), `tap`, `swipe`, `pinch`, `band` (where to search), `near` (tolerant color compare), `runWidth` (measure on screen), `center` and `lines` (turn OCR boxes into tappable text).
- `worker.lua`: native menu, chapter state machine, narration, evidence, error recovery and reports.
- `pages.lua`: responsive English-only presentation and the shared grid geometry.
- `server.lua`: local LuaSocket request handling for real click and form receipts.

Screen recognition and touches use pixel coordinates from `requireScreenMetrics()`, not UIKit points. `findImage` returns a template center; multi-point `findColors` returns an anchor. Rendered colors can differ by a unit or two, so compare them with a tolerance. Check results before touching, and bound every wait.

**Explore more capabilities** in the menu shows a native toast with vibration, live values a script can read on this device (version, screen, orientation, front app, license, Wi-Fi address), and the everyday workflow: record with Volume Down, run, improve with visual checks, schedule with `setTimer()` or Auto Launch, and manage scripts from a computer with WebDAV or the Dashboard. These are learning directions, not verified steps of this tour. The demo does not change existing service settings or add another scripting language.
