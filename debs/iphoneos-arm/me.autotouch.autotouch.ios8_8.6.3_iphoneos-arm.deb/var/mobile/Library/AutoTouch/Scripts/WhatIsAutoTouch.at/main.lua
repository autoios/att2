-- AutoTouch Live Demo. All automation and page logic run in Lua.
-- Open README.md in this package for the tour and reusable API examples.
require("worker").run()
