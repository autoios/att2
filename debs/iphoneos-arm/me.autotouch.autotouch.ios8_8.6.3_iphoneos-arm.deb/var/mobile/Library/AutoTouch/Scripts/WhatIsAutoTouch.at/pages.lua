-- Semantic HTML + CSS only. Links and forms send real browser receipts to Lua.
local M = {}

M.CHAPTERS = {
    {key = "color", menu = "01 · Color & tap", title = "See it. Tap it.", api = "findColors · touchDown/touchUp"},
    {key = "image", menu = "02 · Screenshot & image match", title = "Find a picture.", api = "screenshot · findImage"},
    {key = "draw", menu = "03 · Speed & precision", title = "Draw with taps.", api = "Lua loops · getColors self-check"},
    {key = "scroll", menu = "04 · Smart scrolling", title = "Move with intent.", api = "touchMove · bounded retries"},
    {key = "pinch", menu = "05 · Two-finger pinch", title = "Two fingers at once.", api = "multi-touch · pixel measurement"},
    {key = "text", menu = "06 · Text & data handoff", title = "Make text work.", api = "inputText · form data"},
    {key = "ocr", menu = "07 · Read, decide, act", title = "Read. Decide. Act.", api = "ocr · text boxes · math"},
}
M.RESULTS = #M.CHAPTERS + 1

-- Colors the automation looks for. Each appears on exactly one page.
M.COLOR = {coral = 0xED7046, blue = 0x246BCE, green = 0x28BA98, mint = 0xA8E6CF,
    start = 0xFF8A00, finish = 0x7B2FF7, ink = 0xE63946, ruler = 0xE63946}

-- Drawing grid geometry in CSS pixels; Lua converts it with the measured anchors.
M.GRID = {cell = 32, gap = 5, pad = 14, anchor = 12,
    pattern = {"0110110", "1111111", "1111111", "0111110", "0011100", "0001000"}}
function M.GRID.size()
    local g = M.GRID
    local cols, rows = #g.pattern[1], #g.pattern
    return g.pad * 2 + cols * g.cell + (cols - 1) * g.gap, g.pad * 2 + rows * g.cell + (rows - 1) * g.gap
end

function M.count(n, noun) return n .. " " .. noun .. (n == 1 and "" or "s") end

-- "Stopped by user" -> "Stopped by user."; keeps an existing final period.
function M.sentence(text)
    text = tostring(text)
    return text:find("[%.!?]$") and text or text .. "."
end

function M.escape(value)
    return (tostring(value):gsub("&", "&amp;"):gsub("<", "&lt;")
        :gsub(">", "&gt;"):gsub('"', "&quot;"):gsub("'", "&#39;"))
end

local css = [[
:root{color-scheme:light;--ink:#172b42;--muted:#51657a;--brand:#3d5a80;--paper:#f3f6fa;--line:#d8e1ec}
*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:16px/1.55 -apple-system,BlinkMacSystemFont,"Helvetica Neue",sans-serif;-webkit-text-size-adjust:100%}
main{max-width:680px;margin:auto;padding:20px 24px 40px}header{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;font-size:14px;font-weight:700}
.brand{letter-spacing:-.4px;font-size:20px}.badge{border:1px solid var(--line);border-radius:20px;padding:4px 10px;color:var(--muted);font-size:12px}.exit{display:inline-flex;align-items:center;min-height:44px;font-size:14px;padding-left:12px}
.last{margin:0 0 14px;padding:8px 12px;border-radius:10px;background:#e3f1ec;color:#1d4d40;font-size:13px;line-height:1.4;overflow-wrap:break-word;word-break:break-word}.last.warn{background:#f7ece3;color:#6b3d1d}.last b{letter-spacing:.5px}
.eyebrow{color:var(--brand);font-size:12px;font-weight:700;letter-spacing:1.5px;margin:0 0 8px}h1{font-size:32px;line-height:1.16;letter-spacing:-1px;margin:0 0 12px}h2{font-size:20px;line-height:1.3;margin:0 0 8px}p{margin:8px 0 16px}.intro{color:var(--muted);max-width:48ch}
.progress{display:flex;margin:18px 0;gap:6px}.progress span{height:4px;background:var(--line);flex:1;border-radius:4px}.progress .done{background:var(--brand)}.progress .other{background:#c9a27e}.progress .now{background:#7792b4}
.card{background:white;border:1px solid var(--line);border-radius:20px;padding:24px;margin:16px 0}.stage{min-height:156px;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:12px}
a,button,input{font:inherit}a{color:var(--brand)}.target,button{display:block;min-height:56px;padding:16px 24px;text-align:center;text-decoration:none;border:0;border-radius:12px;font-weight:700;cursor:pointer;touch-action:manipulation}
.coral{background:#ed7046;color:#192b3d}.green{background:#28ba98;color:#102e2b}.image-target{background:#246bce;color:white;position:relative;width:160px;height:96px;border-radius:0;padding:16px;display:block;text-decoration:none}
.image-target i{display:block;background:white;width:64px;height:8px;margin:6px 0 0 40px}.image-target b{position:absolute;left:14px;top:44px;width:20px;height:20px;background:#ffd36a;border-radius:50%}.image-target small{display:block;margin:8px 0 0 40px;font-size:12px}
.code{font:12px/1.7 ui-monospace,Menlo,monospace;color:#35506f;overflow-wrap:break-word;word-break:break-word;background:#eaf0f7;border-radius:10px;padding:12px;margin-top:16px;white-space:pre-wrap}
.quiet{color:var(--muted);font-size:14px}.spacer{height:85vh;display:flex;align-items:center;justify-content:center;color:var(--muted);border-left:2px dashed var(--line);margin:24px 12px;padding:24px}
label{display:block;margin-bottom:8px;font-weight:600}input{-webkit-appearance:none;appearance:none;box-shadow:none;background-image:none;display:block;width:100%;height:64px;background:#a8e6cf;color:#172b42;border:2px solid #34856a;border-radius:12px;padding:16px;font-size:18px;outline-offset:4px}button{width:100%;margin-top:12px;background:var(--brand);color:white}
input[type=hidden]{display:none}
.drawing{text-align:center;margin:16px 0}.grid{position:relative;display:inline-grid;grid-template-columns:repeat(%COLS%,%CELL%px);gap:%GAP%px;padding:%PAD%px;background:white;border-radius:16px;border:1px solid var(--line)}
.grid input{position:absolute;width:1px;height:1px;opacity:0;pointer-events:none}.grid label{display:block;width:%CELL%px;height:%CELL%px;margin:0;background:#dde5f0;border-radius:7px;cursor:pointer;touch-action:manipulation}.grid input:checked+label{background:#e63946}
.anchor{position:absolute;width:%ANCHOR%px;height:%ANCHOR%px}.anchor.start{left:0;top:0;background:#ff8a00}.anchor.finish{right:0;bottom:0;background:#7b2ff7}
.ruler{width:64px;height:24px;background:#e63946;margin:18px auto 8px}.small{font-size:11px;color:var(--muted);text-align:center;margin:0}
.question{font:700 34px/1.3 Menlo,ui-monospace,monospace;letter-spacing:1px;background:white;border:2px solid var(--ink);padding:16px 20px;margin:16px 0}
.answer{display:block;margin:12px 0;padding:12px;text-align:center;background:#3d5a80;color:white;font:700 30px/1.3 Menlo,ui-monospace,monospace;text-decoration:none;border-radius:12px;touch-action:manipulation}
.chapters{margin:0;padding-left:22px}.chapters li{margin:6px 0}.chapters span{display:block;color:var(--muted);font-size:13px}.tip{background:#fff7e0;border:1px solid #f0dca0;border-radius:14px;padding:14px 16px;font-size:14px}
.row{padding:14px 0;border-bottom:1px solid var(--line)}.row:last-child{border:0}.status{font-size:12px;font-weight:700;color:var(--brand);display:block;letter-spacing:.5px}.status.warn{color:#9a5b24}.detail{font-size:14px;color:var(--muted);overflow-wrap:break-word;word-break:break-word}
.steps{margin:0;padding-left:22px}.steps li{margin:8px 0;font-size:15px}
:focus{outline:3px solid #246bce;outline-offset:4px}.target:active,button:active{filter:brightness(.94)}footer{margin-top:24px} @media(max-width:360px){main{padding:16px}h1{font-size:28px}.card{padding:18px}.question{font-size:28px}} @media(max-height:500px){header{margin-bottom:8px}h1{font-size:26px}.card{padding:16px;margin:8px 0}}
]]
css = css:gsub("%%(%u+)%%", {COLS = #M.GRID.pattern[1], CELL = M.GRID.cell, GAP = M.GRID.gap,
    PAD = M.GRID.pad, ANCHOR = M.GRID.anchor})

function M.title(stage)
    if stage == 0 then return "What is AutoTouch?" end
    if stage == M.RESULTS then return "Your automation, delivered." end
    return M.CHAPTERS[stage].title
end

function M.verified(results)
    local count = 0
    for _, result in ipairs(results) do
        if result.status == "VERIFIED" then count = count + 1 end
    end
    return count
end

local function drawing(route)
    local g, cells = M.GRID, {}
    for row = 1, #g.pattern do
        for col = 1, #g.pattern[1] do
            local id = "c" .. row .. "_" .. col
            cells[#cells + 1] = '<input type="checkbox" id="' .. id .. '" name="' .. id .. '" value="1"><label for="'
                .. id .. '" aria-label="Row ' .. row .. ', column ' .. col .. '"></label>'
        end
    end
    return '<form class="drawing" action="' .. route .. '" method="get"><div class="grid">'
        .. '<span class="anchor start"></span><span class="anchor finish"></span>' .. table.concat(cells)
        .. '</div><button class="green" type="submit">Submit drawing</button></form>'
end

local function chapterBody(state, key, route)
    local e = M.escape
    if key == "color" then
        return "AutoTouch finds this button by its color pattern, then sends a real touch. Watch it happen.",
            '<div class="card stage"><a class="target coral" href="' .. route .. '">Find me &amp; tap</a></div>',
            'local p = findColors({{0xED7046, 0, 0}, {0xED7046, 8, 8}}, 1, region)\ntouchDown(0, p[1][1], p[1][2]); touchUp(0, p[1][1], p[1][2])'
    elseif key == "image" then
        return "A small screenshot becomes a visual template. AutoTouch matches it on screen and taps the match.",
            '<div class="card stage"><a class="image-target" aria-label="Image target" href="' .. route .. '"><i></i><i style="width:44px"></i><b></b><small>AUTO / TOUCH</small></a></div>',
            'screenshot("template.png", {x, y, w, h})\nlocal m = findImage("template.png", 1, 0.95)\ntap(m[1][1], m[1][2])'
    elseif key == "draw" then
        local _, count = table.concat(M.GRID.pattern):gsub("1", "")
        return "A Lua loop taps " .. count .. " cells in a few seconds. Then getColors checks every cell, fixes any miss and submits the drawing for an exact comparison.",
            drawing(route),
            'for _, cell in ipairs(heart) do tap(cell.x, cell.y) end\nlocal seen = getColors(allCells) -- verify, then fix'
    elseif key == "scroll" then
        return "The next target is below the fold. AutoTouch swipes, checks the screen and stops when it finds it.",
            '<div class="card"><h2>A gesture with a goal</h2><p class="quiet">Screen-relative coordinates. Smooth motion. Bounded retries.</p></div><div class="spacer">Searching further down ↓</div><div class="card stage"><a class="target green" href="' .. route .. '">Target reached</a></div>',
            'repeat swipeUp() until findColors(target, 1) or swipes == 8\ntap(target)'
    elseif key == "pinch" then
        return "Two simulated fingers move apart at the same time. Safari zooms in, and Lua measures the ruler to prove it.",
            '<div class="card"><div class="ruler"></div><p class="small">64 pt ruler · measured with getColors</p></div>',
            'touchDown(0, x, y - d); touchDown(1, x, y + d)\ntouchMove(0, x, y - D); touchMove(1, x, y + D) -- together'
    elseif key == "text" then
        if state.textMode == "form" then
            return "This tour adapts to your setup. Lua prepares your text, then AutoTouch taps Submit and checks the browser's response. No keyboard input is needed.",
                '<form class="card" action="' .. route .. '" method="get"><label for="message">Prepared by Lua</label><input id="message" name="message" type="text" readonly value="' .. e(state.payload) .. '"><input type="hidden" name="mode" value="form"><button class="green" type="submit">Submit &amp; verify</button></form>',
                'Lua data → HTML form → automated tap\nCompare the browser receipt with the original'
        end
        return "The script focuses this demo field and enters your text. The form checks every character received.",
            '<form class="card" action="' .. route .. '" method="get"><label for="message">Your demo message</label><input id="message" name="message" type="text" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" enterkeyhint="go"><input type="hidden" name="mode" value="keyboard"><button type="submit">Verify text</button></form>',
            'inputText(' .. string.format('%q', state.payload) .. ')\nCompare received text with the original'
    elseif key == "ocr" then
        local puzzle = state.puzzle or {a = 0, b = 0, options = {}}
        local answers = {}
        for _, value in ipairs(puzzle.options) do
            answers[#answers + 1] = '<a class="answer" href="' .. route .. '?answer=' .. value .. '">' .. value .. '</a>'
        end
        return "The numbers change every run. On-device OCR reads the question, Lua does the math, then taps the answer by finding its text.",
            '<div class="question">' .. puzzle.a .. ' + ' .. puzzle.b .. ' = ?</div>' .. table.concat(answers),
            'local lines = ocr({region = region})\nlocal a, b = question:match(pattern)\ntap(center(boxWithText(a + b)))'
    end
end

local function statusClass(status) return status == "VERIFIED" and "" or " warn" end

function M.render(state)
    local e = M.escape
    local stage = state.stage
    local route = state.base .. "/ack/" .. stage
    local body, subtitle, code
    local eyebrow = string.format("LIVE DEMO / %02d OF %02d", stage, #M.CHAPTERS)
    if stage == 0 then
        eyebrow = "LIVE DEMO"
        subtitle = "AutoTouch automates iPhone and iPad. It sees the screen, touches it and makes decisions in Lua. This tour runs itself: please do not touch the screen."
        local items = {}
        for index = state.first or 1, state.last or #M.CHAPTERS do
            local chapter = M.CHAPTERS[index]
            items[#items + 1] = '<li><strong>' .. e(chapter.title) .. '</strong><span>' .. e(chapter.api) .. '</span></li>'
        end
        body = '<div class="card"><ol class="chapters" start="' .. (state.first or 1) .. '">' .. table.concat(items) .. '</ol></div>'
            .. '<p class="tip">Tip: turn on AutoTouch › Settings › Touch Indicator to see every simulated finger. Hold Volume Down at any time to stop.</p>'
            .. '<p class="quiet">Starting automatically. <a href="' .. route .. '">Start now</a></p>'
        code = 'appActivate("com.apple.mobilesafari")\nopenURL(localPlayground) -- served by this script with LuaSocket'
    elseif stage == M.RESULTS then
        eyebrow = "WORKFLOW / RESULTS"
        local planned = (state.last or #M.CHAPTERS) - (state.first or 1) + 1
        subtitle = string.format("%d of %s verified", M.verified(state.results), M.count(planned, "chapter"))
            .. (state.duration and string.format(" in %d s", state.duration) or "") .. "."
            .. (state.stopReason and " Ended early: " .. M.sentence(state.stopReason) or "")
            .. " Every row is evidence from this run, saved as JSON and HTML."
        local rows = {}
        for _, result in ipairs(state.results) do
            local chapter = M.CHAPTERS[result.stage]
            rows[#rows + 1] = '<div class="row"><span class="status' .. statusClass(result.status) .. '">' .. e(result.status)
                .. '</span><strong>' .. e(chapter and chapter.title or "") .. '</strong><div class="detail">' .. e(result.detail) .. '</div></div>'
        end
        body = '<div class="card">' .. table.concat(rows) .. '</div><p class="quiet">' .. e(state.saved or "") .. '</p>'
            .. '<div class="card"><h2>Make it yours</h2><ol class="steps">'
            .. '<li><strong>Record.</strong> Hold Volume Down to open the AutoTouch panel and tap the red Record button. Hold Volume Down again to stop. The gesture is saved as editable Lua in Scripts/Records.</li>'
            .. '<li><strong>Add conditions.</strong> Wrap taps in findColors, findImage or ocr checks with bounded retries. toolkit.lua in this package has ready-made helpers.</li>'
            .. '<li><strong>Run it.</strong> Tap ▶ next to a script in AutoTouch. Hold Volume Down to stop any running script.</li>'
            .. '<li><strong>Automate further.</strong> Schedule with setTimer, start scripts with Settings › Auto Launch, and manage files from a computer with Settings › WebDAV Server or the Dashboard.</li>'
            .. '</ol></div>'
        code = "record → add a visual condition → run → check the result"
    else
        local chapter = M.CHAPTERS[stage]
        subtitle, body, code = chapterBody(state, chapter.key, route)
    end
    local last = ""
    local previous = state.results[#state.results]
    if previous and stage ~= M.RESULTS and not state.archived then
        last = '<p class="last' .. statusClass(previous.status) .. '"><b>' .. e(previous.status) .. '</b> · '
            .. string.format("Chapter %02d: ", previous.stage) .. e(previous.summary or previous.detail or "") .. '</p>'
    end
    local progress, byStage = {}, {}
    for _, result in ipairs(state.results) do byStage[result.stage] = result.status end
    for i = 1, #M.CHAPTERS do
        local class = byStage[i] == "VERIFIED" and "done" or byStage[i] and "other" or i == stage and "now" or nil
        progress[i] = '<span' .. (class and ' class="' .. class .. '"' or '') .. '></span>'
    end
    local exitLink = state.archived and '<span class="badge">SAVED REPORT</span>'
        or '<a class="exit" href="' .. state.base .. '/stop">Finish</a>'
    local footer = state.archived and "Saved locally by AutoTouch. This report can be read offline."
        or "Lua drives every action; this page has no JavaScript and is served by the script itself with LuaSocket. Hold Volume Down to stop."
            .. (stage == M.RESULTS and " This page returns to AutoTouch after 25 seconds." or "")
    return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>AutoTouch · Live Demo</title><style>'
        .. css .. '</style></head><body><main><header><span class="brand">AutoTouch<span style="color:#7792b4"> / </span>Live</span>'
        .. exitLink .. '</header>' .. last .. '<p class="eyebrow">' .. eyebrow .. '</p><h1>' .. e(M.title(stage)) .. '</h1><p class="intro">'
        .. e(subtitle) .. '</p><div class="progress" aria-label="Progress">' .. table.concat(progress) .. '</div>' .. body
        .. '<div class="code">' .. e(code) .. '</div><footer><p class="quiet">' .. e(footer) .. '</p></footer></main></body></html>'
end

return M
