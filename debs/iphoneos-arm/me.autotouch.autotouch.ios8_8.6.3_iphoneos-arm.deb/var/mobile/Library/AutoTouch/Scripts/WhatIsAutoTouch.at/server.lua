-- A short-lived, loopback-only HTTP server for the demo's own playground.
-- No filesystem routes, external requests, JavaScript, or background process.
local M = {}

function M.decode(value)
    return (value:gsub("+", " "):gsub("%%(%x%x)", function(hex)
        return string.char(tonumber(hex, 16))
    end))
end

function M.request(line)
    local target = line:match("^GET (/[^ ]*) HTTP/1%.[01]$")
    if not target or #target > 4096 then return nil end
    local path, query = target:match("^([^?]*)%??(.*)$")
    local params = {}
    for key, value in query:gmatch("([^&=]+)=([^&]*)") do
        params[M.decode(key)] = M.decode(value)
    end
    return path, params
end

function M.start(socket)
    local listener = assert(socket.bind("127.0.0.1", 0), "Cannot open demo playground")
    listener:settimeout(0)
    local _, port = listener:getsockname()
    local server = {listener = listener, url = "http://127.0.0.1:" .. port}

    function server:poll(handler)
        local client = self.listener:accept()
        if not client then return end
        -- A speculative browser connection must not stall the automation loop.
        client:settimeout(0.15)
        local ok, failure = pcall(function()
            local line = client:receive("*l")
            local path, params
            if line then path, params = M.request(line) end
            if not path then return end
            local complete = false
            for _ = 1, 40 do
                local header = client:receive("*l")
                if not header or #header > 8192 then break end
                if header == "" then complete = true; break end
            end
            if not complete then return end
            local body, status = handler(path, params)
            status = status or "200 OK"
            local response = "HTTP/1.1 " .. status .. "\r\nContent-Type: text/html; charset=utf-8\r\n"
                .. "Cache-Control: no-store\r\nConnection: close\r\n"
                .. "Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'\r\n"
                .. "Content-Length: " .. #body .. "\r\n\r\n" .. body
            client:settimeout(0.5)
            local sent = 0
            while sent < #response do
                local last, err, partial = client:send(response, sent + 1)
                sent = last or partial or sent
                if err then error("Demo page could not be delivered: " .. err) end
            end
        end)
        client:close()
        if not ok then error(failure, 0) end
    end

    function server:close()
        self.listener:close()
    end
    return server
end

return M
