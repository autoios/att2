-- Reusable building blocks from the tour. Copy any function into your own script.
-- Coordinates are screen pixels from requireScreenMetrics(), not UIKit points.
local M = {}
local held = {} -- finger index -> {x, y}; released by releaseTouches() after errors

function M.metrics(tag)
    local m = requireScreenMetrics(tag or "WhatIsAutoTouch.liveDemo")
    assert(m.pixelWidth > 0 and m.pixelHeight > 0 and m.scale > 0, "Screen metrics unavailable")
    return m
end

-- Rendered colors can differ by a few units per channel, so compare with a tolerance.
function M.near(color, expected, tolerance)
    tolerance = tolerance or 16
    for shift = 0, 16, 8 do
        local a = math.floor(color / 2 ^ shift) % 256
        local b = math.floor(expected / 2 ^ shift) % 256
        if math.abs(a - b) > tolerance then return false end
    end
    return true
end

-- The part of the screen worth searching: below the status bar, address bar and any
-- toast (toasts are part of the screen image), above the bottom toolbar.
function M.band(m, avoidToast)
    local top = math.floor(m.pixelHeight * .12)
    if avoidToast then top = math.max(top, math.floor(165 * m.scale)) end
    return {0, top, m.pixelWidth, math.floor(m.pixelHeight * .88) - top}
end

-- A 4-point pattern rejects stray single pixels. Re-sample the anchor before acting.
function M.locate(color, region)
    local points = findColors({{color, 0, 0}, {color, 8, 0}, {color, 0, 8}, {color, 8, 8}}, 1, region)
    local point = points and points[1]
    if not point then return nil end
    local sample = getColors({{point[1], point[2]}})
    if not sample or not sample[1] or not M.near(sample[1], color, 8) then return nil end
    return point
end

function M.tap(x, y, holdMicroseconds)
    held[0] = {x, y}
    touchDown(0, x, y)
    usleep(holdMicroseconds or 65000)
    touchUp(0, x, y)
    held[0] = nil
end

-- Smooth, screen-relative swipe: the same fractions work on every screen size.
function M.swipe(m, fromFraction, toFraction)
    local x = math.floor(m.pixelWidth * .5)
    local from = math.floor(m.pixelHeight * (fromFraction or .72))
    local to = math.floor(m.pixelHeight * (toFraction or .36))
    held[0] = {x, from}
    touchDown(0, x, from)
    for step = 1, 24 do
        local f = step / 24
        local y = math.floor(from + (to - from) * f * f * (3 - 2 * f))
        held[0] = {x, y}
        touchMove(0, x, y)
        usleep(16000)
    end
    touchUp(0, x, to)
    held[0] = nil
end

-- Two fingers move apart (or together) around a center point at the same time.
function M.pinch(cx, cy, fromDistance, toDistance, steps)
    steps = steps or 30
    local function place(d)
        local a, b = math.floor(cy - d), math.floor(cy + d)
        held[0], held[1] = {cx, a}, {cx, b}
        return a, b
    end
    local a, b = place(fromDistance)
    touchDown(0, cx, a)
    touchDown(1, cx, b)
    for step = 1, steps do
        local f = step / steps
        a, b = place(fromDistance + (toDistance - fromDistance) * f * f * (3 - 2 * f))
        touchMove(0, cx, a)
        touchMove(1, cx, b)
        usleep(16000)
    end
    usleep(80000)
    touchUp(0, cx, a)
    touchUp(1, cx, b)
    held[0], held[1] = nil, nil
end

function M.releaseTouches()
    for finger, point in pairs(held) do
        pcall(touchUp, finger, point[1], point[2])
        held[finger] = nil
    end
end

function M.holding()
    return next(held) ~= nil
end

-- Length in pixels of the longest horizontal run of a color on one screen row.
function M.runWidth(color, y, m, step)
    step = step or 2
    local points = {}
    for x = 0, m.pixelWidth - 1, step do points[#points + 1] = {x, y} end
    local colors = getColors(points) or {}
    local best, run = 0, 0
    for _, value in ipairs(colors) do
        run = M.near(value, color) and run + 1 or 0
        if run > best then best = run end
    end
    return best * step
end

-- OCR returns text boxes. Center of a box = where to tap that text.
function M.center(rectangle)
    local x, y = 0, 0
    for _, corner in ipairs({"topLeft", "topRight", "bottomLeft", "bottomRight"}) do
        x = x + rectangle[corner].x / 4
        y = y + rectangle[corner].y / 4
    end
    return math.floor(x + .5), math.floor(y + .5)
end

-- Joins OCR boxes into top-to-bottom lines of left-to-right text.
function M.lines(result)
    local items = {}
    for _, item in ipairs(result or {}) do
        if type(item.text) == "string" and type(item.rectangle) == "table" then
            local x, y = M.center(item.rectangle)
            local height = math.abs(item.rectangle.bottomLeft.y - item.rectangle.topLeft.y)
            items[#items + 1] = {text = item.text, x = x, y = y, height = math.max(height, 1)}
        end
    end
    table.sort(items, function(a, b) return a.y < b.y end)
    local lines = {}
    for _, item in ipairs(items) do
        local line = lines[#lines]
        if line and math.abs(item.y - line.y) < math.max(item.height, line.height) / 2 then
            line.items[#line.items + 1] = item
        else
            lines[#lines + 1] = {y = item.y, height = item.height, items = {item}}
        end
    end
    for _, line in ipairs(lines) do
        table.sort(line.items, function(a, b) return a.x < b.x end)
        local words = {}
        for _, item in ipairs(line.items) do words[#words + 1] = item.text end
        line.text = table.concat(words, " ")
    end
    return lines, items
end

return M
