-- Live, observable automation against our own disposable browser playground.
-- The tour state machine lives here; reusable screen and touch helpers are in toolkit.lua.
local pages = require("pages")
local http = require("server")
local kit = require("toolkit")
local M = {}
local APP = "me.autotouch.AutoTouch.ios8"
local SAFARI = "com.apple.mobilesafari"
local CHAPTERS, RESULTS, COLOR = pages.CHAPTERS, pages.RESULTS, pages.COLOR

-- The Lua symbol exists in both editions. Read the actual injection filter;
-- an unreadable or unfamiliar layout is unknown, not proof of availability.
function M.inputTextCapability()
    if type(inputText) ~= "function" then return false end
    if type(plistFileToJsonString) ~= "function" then return nil end
    local known
    for _, path in ipairs({"/var/jb/Library/MobileSubstrate/DynamicLibraries/ATTweak.plist",
        "/Library/MobileSubstrate/DynamicLibraries/ATTweak.plist"}) do
        local ok, filter = pcall(function()
            return require("json").decode(plistFileToJsonString(path)).Filter
        end)
        if ok and type(filter) == "table" and type(filter.Bundles) == "table" then
            local enabled, springboardOnly = false, #filter.Bundles > 0
            for _, bundle in ipairs(filter.Bundles) do
                if bundle == "com.apple.UIKit" or bundle == SAFARI then enabled = true end
                if bundle ~= "com.apple.springboard" then springboardOnly = false end
            end
            local value
            if enabled then value = true
            elseif springboardOnly and not filter.Classes and not filter.Executables then value = false end
            if value ~= nil then
                if known ~= nil and known ~= value then return nil end
                known = value
            end
        end
    end
    return known
end

local function button(title, flag, primary)
    return {type = CONTROLLER_TYPE.BUTTON, title = title, flag = flag,
        color = primary and 0x3D5A80 or 0x60758A, width = 1, collectInputs = true}
end

local function notice(message)
    -- alert() is asynchronous; wait before presenting the next menu.
    dialog({{type = CONTROLLER_TYPE.LABEL, text = message},
        button("Back to menu", 1, true)})
end

local function writeFile(path, value)
    local file = assert(io.open(path, "wb"))
    local written, err = file:write(value)
    local closed, closeError = file:close()
    assert(written, err)
    assert(closed, closeError)
end

local function outputDirectory()
    local lfs = require("lfs")
    local root = currentDir() .. "/results"
    if not lfs.attributes(root) then assert(lfs.mkdir(root)) end
    for index = 1, 100 do
        local path = root .. "/" .. os.date("%Y%m%d-%H%M%S") .. "-" .. index
        if lfs.mkdir(path) then return path end
    end
    error("Cannot create a new demo results directory")
end

local function exists(path)
    local file = io.open(path, "rb")
    if not file then return false end
    local content = file:read(8)
    file:close()
    return content == "\137PNG\r\n\26\n"
end

-- Fresh numbers every run, so the answer cannot be hard-coded.
local function newPuzzle()
    local a, b = math.random(12, 48), math.random(12, 48)
    local answer = a + b
    local options = {answer, answer + 10, answer - 11}
    for i = #options, 2, -1 do
        local j = math.random(i)
        options[i], options[j] = options[j], options[i]
    end
    return {a = a, b = b, answer = answer, options = options}
end

local count = pages.count

-- Lua prefixes runtime errors with "file.lua:line: " (once per rethrow); people should read only the message.
function M.plain(reason)
    local text, stripped = tostring(reason), 1
    while stripped > 0 do text, stripped = text:gsub("^[^\n]-%.lua:%d+: ", "") end
    return text
end
local plain = M.plain

local function drawingMatches(params)
    local g = pages.GRID
    for row = 1, #g.pattern do
        for col = 1, #g.pattern[1] do
            if (params["c" .. row .. "_" .. col] == "1") ~= (g.pattern[row]:sub(col, col) == "1") then return false end
        end
    end
    return true
end

function M.session(config)
    local socket = require("socket")
    local json = require("json")
    local server = http.start(socket)
    math.randomseed(math.floor(socket.gettime() * 1000) % 2147483647)
    local state = {stage = config.intro and 0 or config.first, first = config.first, last = config.last,
        results = {}, payload = config.payload, base = "/demo-" .. math.floor(socket.gettime() * 1000),
        textMode = M.inputTextCapability() == false and "form" or "keyboard"}
    local started = socket.gettime()
    local output, saved
    local loaded, nextAction, stageStarted, awaiting, attempts, step
    local finished = false
    local planned = config.last - config.first + 1
    local deadline = started + 120
    local phaseGeneration = 0
    local narrate = type(toast) == "function"
    local portrait = true
    local toastUntil, pendingToast = 0, nil

    -- Native toasts narrate each step over Safari. They are part of the screen
    -- image, so searches use a band below them and toasts never overlap each other.
    local function say(text)
        if not narrate or not portrait then return end
        local now = socket.gettime()
        if now < toastUntil then pendingToast = text; return end
        pendingToast, toastUntil = nil, now + (config.toastSeconds or 1) + .2
        pcall(toast, text, config.toastSeconds or 1)
    end

    local function resetStage()
        phaseGeneration = phaseGeneration + 1
        loaded, awaiting = false, false
        attempts, stageStarted, step = 0, socket.gettime(), {}
        nextAction = stageStarted + config.delay
        if CHAPTERS[state.stage] and CHAPTERS[state.stage].key == "ocr" then state.puzzle = newPuzzle() end
    end
    resetStage()

    local function directory()
        if not output then output = outputDirectory() end
        return output
    end

    local function record(status, detail, summary, evidence)
        local chapter = CHAPTERS[state.stage]
        state.results[#state.results + 1] = {stage = state.stage, chapter = chapter.key, status = status,
            detail = detail, summary = summary, evidence = evidence,
            textMode = chapter.key == "text" and state.textMode or nil}
        log("[AutoTouch Demo] " .. chapter.key .. " / " .. status .. " / " .. detail)
    end

    local function save()
        -- Tour time only: the results page may stay open afterwards and be saved again.
        state.duration = state.duration or math.floor(socket.gettime() - started + .5)
        local report = {demo = "WhatIsAutoTouch", version = getVersion(),
            timestamp = os.date("!%Y-%m-%dT%H:%M:%SZ"), results = state.results,
            verified = pages.verified(state.results), durationSeconds = state.duration,
            message = state.payload, stopReason = state.stopReason}
        local path = directory()
        writeFile(path .. "/report.json", json.encode(report))
        -- Read back the data: a successful write alone is not the whole workflow.
        local file = assert(io.open(path .. "/report.json", "rb"))
        local serialized = file:read("*a")
        file:close()
        assert(json.decode(serialized).message == state.payload, "Report read-back failed")
        state.saved = "Saved in this script package: " .. path:match("results/.*") .. "/report.json"
        local archive = {}
        for key, value in pairs(state) do archive[key] = value end
        archive.archived = true
        writeFile(path .. "/report.html", pages.render(archive))
        saved = path
    end

    local function advance()
        if state.stage == 0 then state.stage = config.first
        else state.stage = state.stage < config.last and state.stage + 1 or RESULTS end
        resetStage()
        deadline = socket.gettime() + 120
        if state.stage == RESULTS then
            save()
            say(string.format("Report saved · %d of %d verified", pages.verified(state.results), planned))
        end
    end

    local function navigate()
        openURL(server.url .. state.base .. "/view/" .. phaseGeneration)
    end

    local function useFormWorkflow(reason)
        log("[AutoTouch Demo] Text entry adapted: " .. plain(reason))
        state.textMode = "form"
        resetStage()
        navigate() -- Reload also dismisses any keyboard from the previous form.
    end

    local function metrics()
        assert(frontMostAppId() == SAFARI,
            "Safari is no longer in front.")
        local m = kit.metrics()
        portrait = m.pixelHeight > m.pixelWidth
        return m
    end

    local function region(m) return kit.band(m, narrate and portrait) end
    local function ms(since) return math.floor((socket.gettime() - since) * 1000 + .5) end
    -- Gentle swipe that reveals a partly hidden target without skipping past it.
    local function nudge(m) kit.swipe(m, .70, .50) end

    local function tapTarget(x, y)
        awaiting, step.tappedAt = true, socket.gettime()
        kit.tap(x, y)
    end

    -- A Lua-verified chapter stays on screen briefly so viewers can see the result.
    local function complete(status, detail, summary)
        record(status, detail, summary, step.evidence)
        awaiting, step.advanceAt = true, socket.gettime() + config.delay
    end

    local actions = {}

    function actions.color(m)
        local since = socket.gettime()
        local p = kit.locate(COLOR.coral, region(m))
        if not p then
            if attempts >= 2 then nudge(m) end
            return
        end
        step.evidence = {x = p[1], y = p[2], searchMs = ms(since)}
        say(string.format("findColors: button at %d, %d → tap", p[1], p[2]))
        tapTarget(p[1] + 4, p[2] + 4)
    end

    function actions.image(m)
        local p = kit.locate(COLOR.blue, region(m))
        if not p then
            if attempts >= 2 then nudge(m) end
            return
        end
        local size = math.floor(64 * m.scale)
        local area = {p[1], p[2], math.min(size, m.pixelWidth - p[1]), math.min(size, m.pixelHeight - p[2])}
        local template = directory() .. "/template.png"
        screenshot(template, area)
        assert(exists(template), "The template screenshot was not saved.")
        local since = socket.gettime()
        local matches = findImage(template, 1, .95, nil, false, 1)
        local match = matches and matches[1]
        assert(match, "No image match. Keep the demo visible and try again.")
        local x, y = math.floor(match[1] + .5), math.floor(match[2] + .5)
        assert(math.abs(x - (area[1] + area[3] / 2)) < 12 * m.scale
            and math.abs(y - (area[2] + area[4] / 2)) < 12 * m.scale,
            "The image match is outside the demo target.")
        step.evidence = {x = x, y = y, width = area[3], height = area[4], searchMs = ms(since)}
        say(string.format("findImage: match at %d, %d → tap", x, y))
        tapTarget(x, y)
    end

    -- Converts the grid's CSS geometry to screen pixels using its two corner anchors,
    -- so the drawing lands correctly at any display scale or Safari zoom level.
    local function drawingCells(a, b)
        local g = pages.GRID
        local width, height = g.size()
        local zx, zy = (b[1] - a[1]) / (width - g.anchor), (b[2] - a[2]) / (height - g.anchor)
        assert(zx > .5 and zy > .5 and math.abs(zx - zy) <= .08 * zx, "The drawing grid is not where expected.")
        local cells = {}
        for row = 1, #g.pattern do
            for col = 1, #g.pattern[1] do
                local center = g.cell / 2
                cells[#cells + 1] = {
                    x = math.floor(a[1] + (g.pad + (col - 1) * (g.cell + g.gap) + center) * zx + .5),
                    y = math.floor(a[2] + (g.pad + (row - 1) * (g.cell + g.gap) + center) * zy + .5),
                    on = g.pattern[row]:sub(col, col) == "1"}
            end
        end
        return cells
    end

    local function mismatches(cells)
        local points = {}
        for index, cell in ipairs(cells) do points[index] = {cell.x, cell.y} end
        local colors = getColors(points)
        assert(type(colors) == "table" and #colors == #cells, "The drawing could not be read from the screen.")
        local wrong = {}
        for index, cell in ipairs(cells) do
            if kit.near(colors[index], COLOR.ink, 24) ~= cell.on then wrong[#wrong + 1] = cell end
        end
        return wrong
    end

    function actions.draw(m)
        if not step.drawn then
            local area = region(m)
            local a, b = kit.locate(COLOR.start, area), kit.locate(COLOR.finish, area)
            if not (a and b) then
                if attempts >= 2 then nudge(m) end
                return
            end
            local cells, plan = drawingCells(a, b), {}
            for _, cell in ipairs(cells) do
                if cell.on then plan[#plan + 1] = cell end
            end
            say(string.format("Lua loop: tapping %d cells", #plan))
            local since = socket.gettime()
            for _, cell in ipairs(plan) do
                kit.tap(cell.x, cell.y, 30000)
                usleep(config.tapGap or 45000)
            end
            local seconds = socket.gettime() - since
            usleep(300000)
            -- Check the screen, not the plan: re-tap any cell that did not change.
            local wrong, corrected = mismatches(cells), 0
            for _ = 1, 2 do
                if #wrong == 0 then break end
                for _, cell in ipairs(wrong) do
                    kit.tap(cell.x, cell.y, 30000)
                    usleep(config.tapGap or 45000)
                end
                corrected = corrected + #wrong
                usleep(300000)
                wrong = mismatches(cells)
            end
            assert(#wrong == 0, string.format("%d cells still differ after self-correction.", #wrong))
            screenshot(directory() .. "/drawing.png")
            step.drawn = true
            step.evidence = {taps = #plan, seconds = math.floor(seconds * 10 + .5) / 10,
                cells = #cells, corrected = corrected}
            say(string.format("getColors: %d of %d cells correct", #cells, #cells))
        end
        local submit = kit.locate(COLOR.green, region(m))
        if not submit then nudge(m); return end -- The drawing stays; only scroll to the button.
        tapTarget(submit[1] + 10, submit[2] + 10)
    end

    function actions.scroll(m)
        local swipes = step.swipes or 0
        local p = kit.locate(COLOR.green, region(m))
        if p then
            step.evidence = {swipes = swipes, x = p[1], y = p[2]}
            say("Target visible after " .. count(swipes, "swipe") .. " → tap")
            tapTarget(p[1] + 4, p[2] + 4)
            return
        end
        assert(swipes < 8, "The scroll target is still out of view.")
        step.swipes = swipes + 1
        say(string.format("Swipe %d: target not visible yet", step.swipes))
        kit.swipe(m)
    end

    function actions.pinch(m)
        local area = region(m)
        local ruler = kit.locate(COLOR.ruler, area)
        if not ruler then
            if attempts >= 2 then nudge(m) end
            return
        end
        local before = kit.runWidth(COLOR.ruler, ruler[2] + math.floor(12 * m.scale), m)
        assert(before > 0, "The ruler could not be measured.")
        local near, far = math.floor(40 * m.scale), math.floor(150 * m.scale)
        local cy = math.max(area[2] + far, math.min(area[2] + area[4] - far, ruler[2]))
        say("Two fingers: pinch out")
        kit.pinch(math.floor(m.pixelWidth / 2), cy, near, far)
        usleep(700000)
        local zoomed = kit.locate(COLOR.ruler, region(metrics()))
        local after = zoomed and kit.runWidth(COLOR.ruler, zoomed[2] + math.floor(4 * m.scale), m) or 0
        local zoom = after / before
        assert(zoom >= 1.4, string.format("Safari did not zoom (measured %.1f×).", zoom))
        screenshot(directory() .. "/pinch.png")
        step.evidence = {before = before, after = after, zoom = math.floor(zoom * 10 + .5) / 10}
        say(string.format("getColors: zoom measured %.1f×", zoom))
        complete("VERIFIED", string.format("Two fingers moved apart at the same time; Safari zoomed the page %.1f× "
            .. "(ruler %d → %d px, measured with getColors).", zoom, before, after),
            string.format("zoom %.1f× measured", zoom))
    end

    function actions.text(m)
        if state.textMode == "form" then
            local p = kit.locate(COLOR.green, region(m))
            if p then
                say("Lua filled the form → tap Submit")
                tapTarget(p[1] + 4, p[2] + 4)
            elseif attempts >= 2 then nudge(m) end
            return
        end
        if step.inputSent then return end
        local p = kit.locate(COLOR.mint, region(m))
        if not p then
            if attempts >= 2 then nudge(m) end
            return
        end
        kit.tap(p[1] + 4, p[2] + 4)
        usleep(650000)
        metrics()
        step.inputSent, awaiting = true, true
        say("inputText: typing your message")
        local entered, inputError = pcall(inputText, state.payload .. "\n")
        if not entered then useFormWorkflow(inputError) end
    end

    function actions.ocr(m)
        local since = socket.gettime()
        local result, failure = ocr({method = OCR_METHOD.IOS_VISION, languages = {"en-US"},
            timeout = 10, region = region(m)})
        assert(type(result) == "table", tostring(failure or "OCR did not return text"))
        local lines, items = kit.lines(result)
        local questionY
        for _, line in ipairs(lines) do
            local a, b = line.text:match("(%d+)%s*%+%s*(%d+)%s*=")
            if a then
                step.a, step.b, questionY = tonumber(a), tonumber(b), line.y
                break
            end
        end
        if not step.a then
            assert(attempts < 3, "OCR has not read the question. Keep the page visible and retry.")
            return
        end
        local answer = step.a + step.b
        local target
        for _, item in ipairs(items) do
            if (not questionY or item.y > questionY) and item.text:match("^%s*(%d+)%s*$") == tostring(answer) then
                target = item
                break
            end
        end
        if not target then
            -- Small screens: the question was read; reveal the answers below it.
            step.searches = (step.searches or 0) + 1
            assert(step.searches <= 3, string.format("OCR read %d + %d but %d is not on screen.", step.a, step.b, answer))
            nudge(m)
            return
        end
        screenshot(directory() .. "/ocr.png")
        step.evidence = {a = step.a, b = step.b, answer = answer, x = target.x, y = target.y, ocrMs = ms(since)}
        say(string.format("OCR: %d + %d = %d → tap %d", step.a, step.b, answer, answer))
        tapTarget(target.x, target.y)
    end

    local function verifyReceipt(key, params)
        local e = step.evidence or {}
        if not awaiting then
            return "MANUAL", "Activated by hand before the script acted; not counted as automation.", "done by hand"
        end
        local latency = string.format("%.2f s", socket.gettime() - (step.tappedAt or socket.gettime()))
        if key == "color" then
            return "VERIFIED", string.format("findColors located the button at (%d, %d) in %d ms; Safari confirmed the tap %s later.",
                e.x, e.y, e.searchMs, latency), string.format("found at %d, %d and tapped", e.x, e.y)
        elseif key == "image" then
            return "VERIFIED", string.format("Captured a %d×%d px template; findImage matched it at (%d, %d) in %d ms; Safari confirmed the tap.",
                e.width, e.height, e.x, e.y, e.searchMs), "template matched and tapped"
        elseif key == "draw" then
            if not drawingMatches(params) then
                return "FAILED", "Safari received a drawing that differs from the plan.", "drawing differs"
            end
            return "VERIFIED", string.format("%d taps in %.1f s; getColors confirmed %d of %d cells (%d corrected); Safari received the exact drawing.",
                e.taps, e.seconds, e.cells, e.cells, e.corrected), string.format("%d taps in %.1f s, all cells correct", e.taps, e.seconds)
        elseif key == "scroll" then
            return "VERIFIED", "Found the target after " .. count(e.swipes, "swipe")
                .. " with visual checks between them; Safari confirmed the tap.", "found after " .. count(e.swipes, "swipe")
        elseif key == "text" then
            if state.textMode == "keyboard" then
                return "VERIFIED", "Keyboard input delivered the exact Unicode message.", "exact text received"
            end
            return "VERIFIED", "Lua prepared the text; an automated form submission returned the exact message. Keyboard input was not used.",
                "exact text received via form"
        elseif key == "ocr" then
            local puzzle = state.puzzle
            if tonumber(params.answer) ~= puzzle.answer then
                return "FAILED", string.format("Safari received %s, but %d + %d = %d.", tostring(params.answer), puzzle.a, puzzle.b, puzzle.answer), "wrong answer"
            end
            return "VERIFIED", string.format("OCR read \"%d + %d\"; Lua computed %d, found that text on screen and tapped it; Safari confirmed %d.",
                e.a, e.b, e.answer, puzzle.answer), string.format("%d + %d = %d, tapped by its text", e.a, e.b, e.answer)
        end
    end

    local function act()
        local m = metrics()
        attempts = attempts + 1
        actions[CHAPTERS[state.stage].key](m)
    end

    local function recover(reason)
        kit.releaseTouches()
        reason = plain(reason)
        local choice = dialog({
            {type = CONTROLLER_TYPE.LABEL, text = pages.title(state.stage) .. "\n\n" .. reason
                .. "\n\n" .. "Retry reopens the demo page. Keep the device unlocked and the page unobstructed. Some APIs require a license or device support."},
            button("Retry this chapter", 1, true),
            button("Skip this chapter", 2),
            button("End demo", 3)})
        if choice == 1 then
            resetStage()
            navigate()
        elseif choice == 2 then
            record("SKIPPED", reason, "skipped")
            advance()
            navigate()
        else
            state.stopReason = reason
            finished = true
        end
        deadline = socket.gettime() + 120
    end

    local function unavailableText()
        record("UNAVAILABLE", "Text submission could not be verified. The tour continued automatically.", "not verified")
        advance()
        navigate()
    end

    local function handle(path, params)
        if path == state.base .. "/stop" then
            state.stopReason = state.stage < RESULTS and "Stopped by user" or nil
            finished = true
            return '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width"><p>'
                .. "Demo ended. You can close this tab." .. '</p>'
        end
        if path == state.base .. "/ack/" .. state.stage and state.stage < RESULTS and not step.advanceAt then
            local chapter = CHAPTERS[state.stage]
            if chapter and chapter.key == "text" and (params.message ~= state.payload or params.mode ~= state.textMode) then
                -- A late keyboard receipt cannot verify the replacement form.
                return pages.render(state)
            end
            if chapter then
                local status, detail, summary = verifyReceipt(chapter.key, params)
                record(status, detail, summary, step.evidence)
            end
            advance()
            loaded, stageStarted = true, socket.gettime()
            nextAction = stageStarted + config.delay
            return pages.render(state)
        end
        if path == state.base .. "/view/" .. phaseGeneration then
            if not loaded then
                loaded, stageStarted = true, socket.gettime()
                nextAction = stageStarted + config.delay
            end
            return pages.render(state)
        end
        return "Not found", "404 Not Found"
    end

    local ok, failure = xpcall(function()
        say("AutoTouch: starting the live demo")
        assert(appActivate(SAFARI, 8), "Safari could not be opened.")
        navigate()
        while not finished do
            server:poll(handle)
            if finished then break end
            local now = socket.gettime()
            local key = CHAPTERS[state.stage] and CHAPTERS[state.stage].key
            if pendingToast and now >= toastUntil then say(pendingToast) end
            if now > deadline then
                state.stopReason = "Demo session timed out"
                finished = true
            elseif state.stage == RESULTS then
                if loaded and now - stageStarted > 25 then finished = true end
            elseif state.stage == 0 then
                if loaded and now - stageStarted > (config.introSeconds or 4) then
                    advance()
                    navigate()
                end
            elseif step.advanceAt then
                if now >= step.advanceAt then
                    advance()
                    navigate()
                end
            elseif key == "text" and state.textMode == "keyboard" and step.inputSent
                and now - stageStarted > config.delay + 6 then
                useFormWorkflow("Keyboard receipt unavailable")
            elseif key == "text" and now - stageStarted > 25 then
                if state.textMode == "keyboard" then useFormWorkflow("Keyboard receipt unavailable")
                else unavailableText() end
            elseif now - stageStarted > 25 then
                recover("No verified result within 25 seconds.")
            elseif loaded and not awaiting and now >= nextAction then
                local actionOK, actionError = pcall(act)
                nextAction = socket.gettime() + config.delay
                if not actionOK then
                    if key == "text" and frontMostAppId() == SAFARI then
                        if state.textMode == "keyboard" then useFormWorkflow(actionError)
                        else unavailableText() end
                    else recover(actionError) end
                end
            end
            usleep(50000)
        end
        if state.stage < RESULTS then
            if state.stage == 0 then state.stage = config.first end
            record("INCOMPLETE", state.stopReason or "Ended early", "ended early")
            state.stage = RESULTS
        end
        save()
    end, function(err) return tostring(err) end)

    -- Never leave an active touch or listening socket behind on normal/error exits.
    kit.releaseTouches()
    server:close()
    if not ok then error(failure, 0) end
    return saved, {verified = pages.verified(state.results), total = planned, duration = state.duration,
        stopReason = state.stopReason}
end

function M.deviceSummary()
    local function value(read)
        local ok, result = pcall(read)
        if not ok or result == nil or result == "" then return "unavailable" end
        return tostring(result)
    end
    local orientations = {"portrait", "portrait upside down", "landscape left", "landscape right", "face up", "face down"}
    return table.concat({
        "LIVE VALUES FROM THIS DEVICE", "",
        "getVersion() → " .. value(getVersion),
        "requireScreenMetrics() → " .. value(function()
            local m = kit.metrics()
            return string.format("%d × %d px, scale %g", m.pixelWidth, m.pixelHeight, m.scale)
        end),
        "getOrientation() → " .. value(function() return orientations[getOrientation()] or getOrientation() end),
        "frontMostAppId() → " .. value(frontMostAppId),
        "isLicensed() → " .. value(isLicensed),
        "getLocalIP() → " .. value(getLocalIP), "",
        "Scripts read values like these to adapt to any screen, app or network."}, "\n")
end

M.EVERYDAY = table.concat({
    "EVERYDAY WORKFLOW", "",
    "Record: hold Volume Down, tap the red Record button, then hold Volume Down again to stop. You get editable Lua in Scripts/Records.",
    "Run: tap ▶ next to a script. Hold Volume Down to stop running scripts.",
    "Improve: add findColors, findImage or ocr checks with retries (see toolkit.lua).",
    "Schedule: setTimer() or Settings › Auto Launch.",
    "Manage from a computer: Settings › WebDAV Server or the AutoTouch Dashboard."}, "\n")

function M.explore()
    while true do
        local choice = dialog({{type = CONTROLLER_TYPE.LABEL,
            text = "EXPLORE MORE\nTry a native feature, or see what a script can read right now."},
            button("Show a toast and vibrate", 1, true), button("What can a script read?", 2),
            button("Everyday workflow", 3), button("Back to menu", 0)})
        if choice == 1 then
            pcall(toast, "Hello from Lua: toast() + vibrate()", 3)
            pcall(vibrate)
        elseif choice == 2 then
            notice(M.deviceSummary())
        elseif choice == 3 then
            notice(M.EVERYDAY)
        else
            return
        end
    end
end

local function completion(path, summary)
    local outcome = string.format("%d of %s verified", summary.verified, count(summary.total, "chapter"))
    local headline = summary.stopReason
        and string.format("Demo stopped: %s\n%s before it ended (%d s).", pages.sentence(summary.stopReason), outcome, summary.duration or 0)
        or string.format("Demo finished: %s in %d s.", outcome, summary.duration or 0)
    return headline .. "\n\nReport and screenshots:\nWhatIsAutoTouch.at/" .. (tostring(path):match("results/.*") or tostring(path))
        .. "\n\nNext: hold Volume Down, tap Record and turn your own gesture into Lua."
end

function M.run()
    local chapters = {"Full experience"}
    for _, chapter in ipairs(CHAPTERS) do chapters[#chapters + 1] = chapter.menu end
    local selection = {type = CONTROLLER_TYPE.PICKER, title = "Chapter", key = "demo-chapter", value = chapters[1], options = chapters}
    local message = {type = CONTROLLER_TYPE.INPUT, title = "Demo text", key = "demo-message", value = "Hello, AutoTouch! Ready ✓"}
    local slow = {type = CONTROLLER_TYPE.SWITCH, title = "Pause longer to explain each step", key = "demo-slow", value = 1}
    while true do
        local choice = dialog({{type = CONTROLLER_TYPE.LABEL,
            text = "Watch Lua see, tap, draw, read and decide.\nHands off. Hold Volume Down to stop."},
            selection, message, slow, button("Start live demo", 1, true),
            button("Explore more capabilities", 2), button("Exit", 0)})
        if choice == 0 or choice == nil then return end
        if choice == 2 then
            M.explore()
        elseif choice == 1 then
            if #message.value == 0 or #message.value > 160 or message.value:find("[%c]") then
                notice("Use a single line of demo text (1–160 UTF-8 bytes).")
            else
                local first, last = 1, #CHAPTERS
                for index = 2, #chapters do
                    if selection.value == chapters[index] then first, last = index - 1, index - 1 end
                end
                local paced = slow.value == 1 or slow.value == true
                local ok, result, summary = pcall(M.session, {first = first, last = last, intro = first ~= last,
                    payload = message.value, delay = paced and 3 or 1.2, toastSeconds = paced and 2 or 1,
                    introSeconds = paced and 7 or 4, tapGap = paced and 110000 or 45000})
                appActivate(APP, 8)
                notice(ok and completion(result, summary) or ("Demo stopped:\n" .. plain(result)))
            end
        else
            return
        end
    end
end

return M
